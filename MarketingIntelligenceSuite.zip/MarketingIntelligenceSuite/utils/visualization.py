import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

def create_kpi_indicator(title, value, delta=None, delta_suffix="", is_inverse=False):
    """
    Creates a KPI indicator with a title, value, and optional delta.
    
    Args:
        title (str): The title of the KPI
        value (any): The current value to display
        delta (float, optional): The change amount to display
        delta_suffix (str, optional): Suffix for the delta value (e.g., "%", "$")
        is_inverse (bool, optional): If True, negative deltas are good (green)
    
    Returns:
        None: Displays the KPI directly using Streamlit
    """
    delta_color = "normal"
    if is_inverse and delta is not None:
        delta_color = "inverse"
    
    if delta is not None:
        delta_formatted = f"{delta}{delta_suffix}"
        st.metric(title, value, delta=delta_formatted, delta_color=delta_color)
    else:
        st.metric(title, value)

def create_comparison_chart(data, x_col, y_cols, title, chart_type="bar"):
    """
    Creates a comparison chart (bar or line) for multiple metrics.
    
    Args:
        data (pd.DataFrame): The data to visualize
        x_col (str): Column name for the x-axis
        y_cols (list): List of column names for the y-axis
        title (str): Chart title
        chart_type (str): "bar" or "line"
    
    Returns:
        plotly.graph_objects.Figure: The created chart
    """
    if chart_type == "bar":
        fig = px.bar(
            data,
            x=x_col,
            y=y_cols,
            title=title,
            barmode='group'
        )
    else:  # line chart
        fig = px.line(
            data,
            x=x_col,
            y=y_cols,
            title=title,
            markers=True
        )
    
    fig.update_layout(
        legend_title=None,
        height=400
    )
    
    return fig

def create_funnel_chart(stages, values, title):
    """
    Creates a funnel chart for conversion visualization.
    
    Args:
        stages (list): List of stage names
        values (list): List of values for each stage
        title (str): Chart title
    
    Returns:
        plotly.graph_objects.Figure: The created funnel chart
    """
    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        textinfo="value+percent initial"
    ))
    
    fig.update_layout(
        title=title,
        height=400
    )
    
    return fig

def create_time_series_chart(data, date_col, value_col, title, color_col=None):
    """
    Creates a time series chart.
    
    Args:
        data (pd.DataFrame): The data to visualize
        date_col (str): Column name for the date
        value_col (str or list): Column name(s) for the values
        title (str): Chart title
        color_col (str, optional): Column name for color differentiation
    
    Returns:
        plotly.graph_objects.Figure: The created time series chart
    """
    if isinstance(value_col, list):
        fig = px.line(
            data,
            x=date_col,
            y=value_col,
            title=title,
            markers=True
        )
    else:
        if color_col:
            fig = px.line(
                data,
                x=date_col,
                y=value_col,
                color=color_col,
                title=title,
                markers=True
            )
        else:
            fig = px.line(
                data,
                x=date_col,
                y=value_col,
                title=title,
                markers=True
            )
    
    fig.update_layout(
        height=400,
        xaxis_title=None,
        yaxis_title=None
    )
    
    return fig

def create_radar_chart(categories, values, title, multiple_series=None):
    """
    Creates a radar chart for multi-dimensional comparison.
    
    Args:
        categories (list): List of category names
        values (list or dict): Values for each category
        title (str): Chart title
        multiple_series (dict, optional): Dict of series name to values list for multiple series
    
    Returns:
        plotly.graph_objects.Figure: The created radar chart
    """
    fig = go.Figure()
    
    if multiple_series:
        for name, series_values in multiple_series.items():
            fig.add_trace(go.Scatterpolar(
                r=series_values,
                theta=categories,
                fill='toself',
                name=name
            ))
    else:
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself'
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, max(values) * 1.1] if not multiple_series else None
            )
        ),
        title=title,
        height=400
    )
    
    return fig

def create_scatter_plot(data, x_col, y_col, title, size_col=None, color_col=None, text_col=None):
    """
    Creates a scatter plot.
    
    Args:
        data (pd.DataFrame): The data to visualize
        x_col (str): Column name for the x-axis
        y_col (str): Column name for the y-axis
        title (str): Chart title
        size_col (str, optional): Column name for point sizes
        color_col (str, optional): Column name for point colors
        text_col (str, optional): Column name for hover text
    
    Returns:
        plotly.graph_objects.Figure: The created scatter plot
    """
    if size_col and color_col:
        fig = px.scatter(
            data,
            x=x_col,
            y=y_col,
            size=size_col,
            color=color_col,
            title=title,
            text=text_col
        )
    elif size_col:
        fig = px.scatter(
            data,
            x=x_col,
            y=y_col,
            size=size_col,
            title=title,
            text=text_col
        )
    elif color_col:
        fig = px.scatter(
            data,
            x=x_col,
            y=y_col,
            color=color_col,
            title=title,
            text=text_col
        )
    else:
        fig = px.scatter(
            data,
            x=x_col,
            y=y_col,
            title=title,
            text=text_col
        )
    
    fig.update_layout(
        height=400
    )
    
    if text_col:
        fig.update_traces(textposition='top center')
    
    return fig

def create_heatmap(data, x_col, y_col, value_col, title):
    """
    Creates a heatmap visualization.
    
    Args:
        data (pd.DataFrame): The data to visualize
        x_col (str): Column name for the x-axis
        y_col (str): Column name for the y-axis
        value_col (str): Column name for the values (color intensity)
        title (str): Chart title
    
    Returns:
        plotly.graph_objects.Figure: The created heatmap
    """
    fig = px.density_heatmap(
        data,
        x=x_col,
        y=y_col,
        z=value_col,
        title=title
    )
    
    fig.update_layout(
        height=400
    )
    
    return fig

def create_pie_chart(data, names_col, values_col, title):
    """
    Creates a pie chart.
    
    Args:
        data (pd.DataFrame): The data to visualize
        names_col (str): Column name for the slice names
        values_col (str): Column name for the slice values
        title (str): Chart title
    
    Returns:
        plotly.graph_objects.Figure: The created pie chart
    """
    fig = px.pie(
        data,
        names=names_col,
        values=values_col,
        title=title
    )
    
    fig.update_layout(
        height=400
    )
    
    return fig

def create_sunburst_chart(data, path_cols, values_col, title):
    """
    Creates a sunburst chart for hierarchical data.
    
    Args:
        data (pd.DataFrame): The data to visualize
        path_cols (list): List of column names forming the hierarchy
        values_col (str): Column name for the values
        title (str): Chart title
    
    Returns:
        plotly.graph_objects.Figure: The created sunburst chart
    """
    fig = px.sunburst(
        data,
        path=path_cols,
        values=values_col,
        title=title
    )
    
    fig.update_layout(
        height=500
    )
    
    return fig

def create_sankey_diagram(nodes, links, title):
    """
    Creates a Sankey diagram for flow visualization.
    
    Args:
        nodes (list): List of node names
        links (dict): Dictionary with source, target, and value keys
        title (str): Chart title
    
    Returns:
        plotly.graph_objects.Figure: The created Sankey diagram
    """
    fig = go.Figure(data=[go.Sankey(
        node=dict(
            pad=15,
            thickness=20,
            line=dict(color="black", width=0.5),
            label=nodes
        ),
        link=dict(
            source=links['source'],
            target=links['target'],
            value=links['value']
        )
    )])
    
    fig.update_layout(
        title=title,
        height=500
    )
    
    return fig