import pandas as pd
import numpy as np
import random
import datetime

def get_webinar_stage_requirements(stage):
    """
    Returns the requirements for a specific stage in the Crawl-Walk-Run webinar framework.
    
    Args:
        stage (str): One of "Crawl", "Walk", or "Run"
    
    Returns:
        dict: Dictionary of requirement categories and items
    """
    requirements = {
        "Crawl": {
            "Technology": [
                "Basic webinar platform (Zoom, WebEx, or Teams)",
                "Simple registration form",
                "Basic slide presentation",
                "Standard Q&A functionality"
            ],
            "Content": [
                "Introductory product overviews",
                "Basic educational content",
                "Simple demonstrations",
                "Limited interactivity"
            ],
            "Promotion": [
                "Email invitations to existing contacts",
                "Website announcements",
                "Basic social media posts",
                "Internal promotion to sales teams"
            ],
            "Analytics": [
                "Registration count tracking",
                "Attendance rate calculation",
                "Basic post-event survey",
                "Manual lead list creation"
            ],
            "Follow-up": [
                "Standard thank you email",
                "Single follow-up with recording",
                "Basic lead handoff to sales",
                "Ad hoc reporting on results"
            ]
        },
        "Walk": {
            "Technology": [
                "Dedicated webinar platform with integrations",
                "Custom branding of webinar experience",
                "Interactive polling and surveys",
                "Breakout room capabilities"
            ],
            "Content": [
                "Segmented content for specific personas",
                "Industry insights and thought leadership",
                "Interactive product demonstrations",
                "Moderated panel discussions"
            ],
            "Promotion": [
                "Multi-channel promotional strategy",
                "Targeted LinkedIn campaigns",
                "Partner co-promotion opportunities",
                "Reminder sequence automation"
            ],
            "Analytics": [
                "Engagement scoring during webinar",
                "Behavioral tracking of attendees",
                "Integration with CRM for lead routing",
                "Conversion tracking from registration to sale"
            ],
            "Follow-up": [
                "Segmented follow-up sequences",
                "Personalized content recommendations",
                "Sales enablement with engagement data",
                "ROI measurement for each webinar"
            ]
        },
        "Run": {
            "Technology": [
                "Integrated webinar ecosystem with marketing automation",
                "Interactive multimedia experience",
                "Personal video networking opportunities",
                "AI-powered content recommendations"
            ],
            "Content": [
                "Highly personalized content paths",
                "Industry-specific use cases and ROI models",
                "Interactive workshops and hands-on sessions",
                "Continuous engagement loops with progressive content"
            ],
            "Promotion": [
                "Account-based marketing approach",
                "Predictive targeting using intent data",
                "Multi-touch attribution across channels",
                "Programmatic advertising with retargeting"
            ],
            "Analytics": [
                "Comprehensive analytics dashboard",
                "AI-driven insights and recommendations",
                "Predictive lead scoring models",
                "Full-funnel attribution reporting"
            ],
            "Follow-up": [
                "Personalized content journeys based on engagement",
                "Automated nurture pathways with dynamic content",
                "Direct integration with sales workflows",
                "Continuous optimization based on conversion data"
            ]
        }
    }
    
    if stage in requirements:
        return requirements[stage]
    else:
        return None

def generate_webinar_sample_data():
    """
    Generate sample webinar performance data for demonstration purposes.
    
    Returns:
        dict: Dictionary containing webinar program metrics
    """
    # Current date for reference
    current_date = datetime.datetime.now()
    
    # Generate past webinar data
    past_webinars = []
    topics = [
        "New Product Introduction: Benefits and Features",
        "Advanced Clinical Applications in Healthcare",
        "Maximizing ROI with Digital Solutions",
        "Industry Trends and Future Outlook",
        "Best Practices for Implementation",
        "Technical Deep Dive: Platform Capabilities",
        "Customer Success Stories and Case Studies",
        "Integration Strategies for Enterprise Systems",
        "Regulatory Compliance in Healthcare",
        "Innovation Showcase: Future Roadmap"
    ]
    
    for i in range(12):
        # Date between 1-12 months ago
        webinar_date = current_date - datetime.timedelta(days=30*i + random.randint(0, 15))
        
        # Select random topic
        topic = random.choice(topics)
        
        # Generate realistic metrics
        registrations = random.randint(120, 450)
        attendance = int(registrations * random.uniform(0.4, 0.65))
        attendance_rate = round((attendance / registrations) * 100, 1)
        
        # Engagement metrics
        avg_view_time = round(random.uniform(25, 50), 1)
        view_time_percentage = round((avg_view_time / 60) * 100, 1)
        poll_participation = round(random.uniform(50, 85), 1)
        q_and_a_participation = round(random.uniform(15, 40), 1)
        
        # Lead conversion metrics
        mql_conversion = round(random.uniform(12, 28), 1)
        sql_conversion = round(random.uniform(5, 15), 1)
        opportunity_conversion = round(random.uniform(2, 8), 1)
        
        past_webinars.append({
            "date": webinar_date.strftime("%Y-%m-%d"),
            "title": topic,
            "registrations": registrations,
            "attendance": attendance,
            "attendance_rate": attendance_rate,
            "avg_view_time_min": avg_view_time,
            "view_time_percentage": view_time_percentage,
            "poll_participation_rate": poll_participation,
            "q_and_a_participation_rate": q_and_a_participation,
            "mql_conversion_rate": mql_conversion,
            "sql_conversion_rate": sql_conversion,
            "opportunity_conversion_rate": opportunity_conversion
        })
    
    # Generate upcoming webinar data
    upcoming_webinars = []
    for i in range(5):
        # Date between now and 3 months in future
        webinar_date = current_date + datetime.timedelta(days=random.randint(7, 90))
        
        # Select random topic
        topic = random.choice(topics)
        
        # Generate realistic metrics
        registrations = random.randint(20, 250)  # Fewer registrations as date is closer
        registration_target = random.randint(250, 400)
        
        upcoming_webinars.append({
            "date": webinar_date.strftime("%Y-%m-%d"),
            "title": topic,
            "current_registrations": registrations,
            "registration_target": registration_target,
            "days_until_event": (webinar_date - current_date).days,
            "registration_percentage": round((registrations / registration_target) * 100, 1)
        })
    
    # Program performance metrics
    monthly_webinars = [2, 3, 2, 3, 2, 3, 4, 3, 2, 3, 3, 4]
    avg_registrations = [180, 210, 195, 230, 240, 270, 320, 290, 250, 310, 330, 380]
    avg_attendance_rates = [42, 45, 44, 48, 50, 51, 55, 53, 52, 56, 58, 60]
    lead_conversion_rates = [10, 12, 11, 14, 15, 16, 18, 17, 16, 19, 20, 22]
    
    # Generate month labels for the last 12 months
    months = []
    for i in range(12):
        month_date = current_date - datetime.timedelta(days=30*(11-i))
        months.append(month_date.strftime("%b %Y"))
    
    program_metrics = {
        "months": months,
        "monthly_webinars": monthly_webinars,
        "avg_registrations": avg_registrations,
        "avg_attendance_rates": avg_attendance_rates,
        "lead_conversion_rates": lead_conversion_rates
    }
    
    # Return complete dataset
    return {
        "past_webinars": past_webinars,
        "upcoming_webinars": upcoming_webinars,
        "program_metrics": program_metrics
    }