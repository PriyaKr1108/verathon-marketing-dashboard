import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_sample_marketing_data(period="Last 30 Days"):
    """
    Generate sample marketing data for demonstration purposes.
    
    Args:
        period (str): Time period for the data
    
    Returns:
        pd.DataFrame: DataFrame with marketing metrics
    """
    # Define date range based on selected period
    end_date = datetime.now()
    
    if period == "Last 7 Days":
        start_date = end_date - timedelta(days=7)
        freq = "D"
    elif period == "Last 30 Days":
        start_date = end_date - timedelta(days=30)
        freq = "D"
    elif period == "Last Quarter":
        start_date = end_date - timedelta(days=90)
        freq = "3D"
    elif period == "Last Year":
        start_date = end_date - timedelta(days=365)
        freq = "W"
    else:  # Custom or default
        start_date = end_date - timedelta(days=30)
        freq = "D"
    
    # Generate date range
    date_range = pd.date_range(start=start_date, end=end_date, freq=freq)
    
    # Create base dataframe
    df = pd.DataFrame({"date": date_range})
    
    # Generate website traffic with upward trend and weekly seasonality
    base_traffic = 2000
    trend_factor = np.linspace(1, 1.2, len(date_range))
    seasonality = np.sin(np.linspace(0, 2*np.pi * (len(date_range)/7), len(date_range))) * 0.1 + 1
    random_factor = np.random.normal(1, 0.05, len(date_range))
    
    df["website_traffic"] = np.round(base_traffic * trend_factor * seasonality * random_factor).astype(int)
    
    # Generate conversion rate with slight improvement over time
    base_conversion = 2.5
    conversion_trend = np.linspace(0, 0.5, len(date_range))
    conversion_random = np.random.normal(0, 0.1, len(date_range))
    
    df["conversion_rate"] = base_conversion + conversion_trend + conversion_random
    df["conversion_rate"] = df["conversion_rate"].clip(1.5, 4.0)
    
    # Generate cost per lead with decreasing trend (improvement)
    base_cpl = 120
    cpl_trend = np.linspace(0, -20, len(date_range))
    cpl_random = np.random.normal(0, 5, len(date_range))
    
    df["cost_per_lead"] = base_cpl + cpl_trend + cpl_random
    df["cost_per_lead"] = df["cost_per_lead"].clip(85, 130)
    
    # Generate bounce rate with improvement over time
    base_bounce = 60
    bounce_trend = np.linspace(0, -10, len(date_range))
    bounce_random = np.random.normal(0, 2, len(date_range))
    
    df["bounce_rate"] = base_bounce + bounce_trend + bounce_random
    df["bounce_rate"] = df["bounce_rate"].clip(45, 65)
    
    # Generate average session duration
    base_duration = 120
    duration_trend = np.linspace(0, 30, len(date_range))
    duration_random = np.random.normal(0, 10, len(date_range))
    
    df["avg_session_duration"] = base_duration + duration_trend + duration_random
    df["avg_session_duration"] = df["avg_session_duration"].clip(100, 180)
    
    # Generate ROI with improvement
    base_roi = 3.2
    roi_trend = np.linspace(0, 0.8, len(date_range))
    roi_random = np.random.normal(0, 0.2, len(date_range))
    
    df["roi"] = base_roi + roi_trend + roi_random
    df["roi"] = df["roi"].clip(2.8, 5.0)
    
    return df

def process_webinar_data(webinar_data):
    """
    Process raw webinar data for analysis.
    
    Args:
        webinar_data (dict): Raw webinar data
    
    Returns:
        dict: Processed webinar metrics
    """
    # This would process real data in a production environment
    processed_data = {
        "registration_count": len(webinar_data.get("registrations", [])),
        "attendance_count": len(webinar_data.get("attendees", [])),
        "attendance_rate": (len(webinar_data.get("attendees", [])) / 
                            len(webinar_data.get("registrations", [])) * 100 
                            if len(webinar_data.get("registrations", [])) > 0 else 0),
        "average_duration": sum([a.get("duration", 0) for a in webinar_data.get("attendees", [])]) / 
                           len(webinar_data.get("attendees", [])) 
                           if len(webinar_data.get("attendees", [])) > 0 else 0,
        "question_count": sum([a.get("questions", 0) for a in webinar_data.get("attendees", [])]),
        "poll_response_rate": sum([a.get("poll_responses", 0) for a in webinar_data.get("attendees", [])]) / 
                              (len(webinar_data.get("attendees", [])) * len(webinar_data.get("polls", [])))
                              if len(webinar_data.get("attendees", [])) > 0 and len(webinar_data.get("polls", [])) > 0 else 0,
    }
    
    return processed_data

def calculate_marketing_roi(campaign_data):
    """
    Calculate ROI for marketing campaigns.
    
    Args:
        campaign_data (dict): Campaign investment and revenue data
    
    Returns:
        dict: ROI metrics
    """
    total_investment = sum([c.get("investment", 0) for c in campaign_data])
    total_revenue = sum([c.get("revenue", 0) for c in campaign_data])
    
    roi_metrics = {
        "total_investment": total_investment,
        "total_revenue": total_revenue,
        "roi": (total_revenue - total_investment) / total_investment if total_investment > 0 else 0,
        "campaign_roi": [
            {
                "campaign_name": c.get("name", "Unknown Campaign"),
                "investment": c.get("investment", 0),
                "revenue": c.get("revenue", 0),
                "roi": (c.get("revenue", 0) - c.get("investment", 0)) / c.get("investment", 0) 
                       if c.get("investment", 0) > 0 else 0
            }
            for c in campaign_data
        ]
    }
    
    return roi_metrics
