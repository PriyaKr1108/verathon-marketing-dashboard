import pandas as pd
import numpy as np
import datetime
import random

def fetch_competitive_data(competitors, timeframe):
    """
    Fetch competitive intelligence data for analysis.
    
    In a real implementation, this would connect to various APIs to get actual data.
    For this demo, we generate realistic sample data.
    
    Args:
        competitors (list): List of competitor names
        timeframe (str): Analysis timeframe
    
    Returns:
        dict: Dictionary of competitive data components
    """
    # Generate various competitive data components
    data = {
        'traffic': generate_traffic_data(competitors, timeframe),
        'domain_metrics': generate_domain_metrics(competitors),
        'digital_footprint': generate_digital_footprint(competitors),
        'seo_metrics': generate_seo_metrics(competitors),
        'social_metrics': get_social_metrics(competitors),
        'seo_performance': get_seo_performance(competitors),
        'webinar_stats': generate_webinar_stats(competitors)
    }
    
    return data

def generate_traffic_data(competitors, timeframe):
    """Generate sample website traffic data for competitors"""
    # Determine date range based on timeframe
    months = 12
    if timeframe == "Last 30 Days":
        months = 1
    elif timeframe == "Last 90 Days":
        months = 3
    elif timeframe == "Last 6 Months":
        months = 6
    
    # Generate date range
    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=30*months)
    date_range = pd.date_range(start=start_date, end=end_date, freq='MS')
    months_str = [d.strftime("%b %Y") for d in date_range]
    
    # Create DataFrame
    df = pd.DataFrame({'Month': months_str})
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate traffic data for each competitor
    for competitor in competitors:
        # Base traffic values vary by competitor
        if competitor == "Verathon":
            base = 45000
            trend = 0.03  # 3% growth per month
            seasonality = 0.1
        elif competitor == "Competitor A":
            base = 65000
            trend = 0.04  # 4% growth per month
            seasonality = 0.05
        elif competitor == "Competitor B":
            base = 55000
            trend = 0.02  # 2% growth per month
            seasonality = 0.08
        elif competitor == "Competitor C":
            base = 35000
            trend = 0.01  # 1% growth per month
            seasonality = 0.15
        else:
            base = np.random.randint(30000, 70000)
            trend = np.random.uniform(0.01, 0.05)
            seasonality = np.random.uniform(0.05, 0.15)
        
        # Generate values with trend and noise
        values = []
        for i in range(len(months_str)):
            # Add trend
            value = base * (1 + trend) ** i
            
            # Add seasonality (higher in certain months)
            season_factor = 1 + seasonality * np.sin(i * np.pi / 6)  # Peak every 12 months
            value *= season_factor
            
            # Add random noise
            noise = np.random.normal(0, 0.05)  # 5% random variation
            value *= (1 + noise)
            
            values.append(int(value))
        
        df[competitor] = values
    
    return df

def generate_domain_metrics(competitors):
    """Generate sample domain metrics for competitors"""
    # Create metrics dictionary
    np.random.seed(42)
    metrics = {
        'Competitor': competitors,
        'Monthly Traffic': [45000, 65000, 55000, 35000][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(30000, 70000) for _ in competitors],
        'Avg. Time on Site (min)': [2.8, 3.5, 3.2, 2.3][:len(competitors)] if len(competitors) <= 4 else [round(np.random.uniform(2.0, 4.0), 1) for _ in competitors],
        'Pages per Visit': [3.2, 4.1, 3.5, 2.9][:len(competitors)] if len(competitors) <= 4 else [round(np.random.uniform(2.5, 4.5), 1) for _ in competitors],
        'Bounce Rate (%)': [56, 42, 48, 62][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(35, 65) for _ in competitors],
        'Organic Keywords': [1800, 3500, 2700, 1200][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(1000, 4000) for _ in competitors],
        'Referring Domains': [350, 870, 620, 280][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(200, 1000) for _ in competitors],
    }
    
    return metrics

def generate_digital_footprint(competitors):
    """Generate sample digital footprint data for radar chart"""
    # Define dimensions
    dimensions = [
        'Digital Presence', 
        'Content Quality', 
        'Social Engagement', 
        'SEO Performance', 
        'Paid Advertising', 
        'Brand Visibility'
    ]
    
    # Create dictionary for each competitor
    footprint = {}
    np.random.seed(42)
    
    for competitor in competitors:
        if competitor == "Verathon":
            # Verathon has decent digital presence but lags in social and SEO
            footprint[competitor] = {
                'Digital Presence': 7,
                'Content Quality': 6,
                'Social Engagement': 4,
                'SEO Performance': 5,
                'Paid Advertising': 7,
                'Brand Visibility': 8
            }
        elif competitor == "Competitor A":
            # Competitor A is strong in most areas
            footprint[competitor] = {
                'Digital Presence': 9,
                'Content Quality': 8,
                'Social Engagement': 8,
                'SEO Performance': 9,
                'Paid Advertising': 7,
                'Brand Visibility': 8
            }
        elif competitor == "Competitor B":
            # Competitor B is balanced with strength in content
            footprint[competitor] = {
                'Digital Presence': 7,
                'Content Quality': 9,
                'Social Engagement': 6,
                'SEO Performance': 7,
                'Paid Advertising': 6,
                'Brand Visibility': 7
            }
        elif competitor == "Competitor C":
            # Competitor C is weaker overall
            footprint[competitor] = {
                'Digital Presence': 5,
                'Content Quality': 5,
                'Social Engagement': 6,
                'SEO Performance': 4,
                'Paid Advertising': 3,
                'Brand Visibility': 4
            }
        else:
            # Random data for other competitors
            footprint[competitor] = {dim: np.random.randint(3, 10) for dim in dimensions}
    
    return footprint

def generate_seo_metrics(competitors):
    """Generate sample SEO metrics for competitors"""
    np.random.seed(42)
    
    metrics = {
        'Competitor': competitors,
        'Domain Authority': [58, 72, 64, 45][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(40, 75) for _ in competitors],
        'Top 3 Keywords': [12, 48, 35, 8][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(5, 50) for _ in competitors],
        'Top 10 Keywords': [65, 210, 145, 42][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(40, 250) for _ in competitors],
        'Top 100 Keywords': [580, 1250, 950, 420][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(400, 1500) for _ in competitors],
        'Backlinks': [15000, 45000, 32000, 12000][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(10000, 50000) for _ in competitors],
    }
    
    return pd.DataFrame(metrics)

def get_social_metrics(competitors):
    """Generate sample social media metrics for competitors"""
    np.random.seed(42)
    
    metrics = {
        'Competitor': competitors,
        'LinkedIn Followers': [12500, 45000, 28000, 8500][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(8000, 50000) for _ in competitors],
        'Twitter Followers': [8200, 32000, 18500, 5300][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(5000, 35000) for _ in competitors],
        'Facebook Followers': [15600, 40000, 22000, 9800][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(9000, 45000) for _ in competitors],
        'Instagram Followers': [5400, 25000, 14500, 3200][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(3000, 30000) for _ in competitors],
        'Posts per Week': [3, 8, 5, 2][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(2, 10) for _ in competitors],
    }
    
    return pd.DataFrame(metrics)

def get_seo_performance(competitors):
    """Generate sample SEO performance data for competitors"""
    # Generate date range for last 12 months
    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=365)
    date_range = pd.date_range(start=start_date, end=end_date, freq='MS')
    months_str = [d.strftime("%b %Y") for d in date_range]
    
    # Create DataFrame
    df = pd.DataFrame({'Month': months_str})
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate SEO visibility score for each competitor
    for competitor in competitors:
        # Base visibility values vary by competitor
        if competitor == "Verathon":
            base = 45
            trend = 0.02  # 2% growth per month
        elif competitor == "Competitor A":
            base = 78
            trend = 0.03  # 3% growth per month
        elif competitor == "Competitor B":
            base = 62
            trend = 0.025  # 2.5% growth per month
        elif competitor == "Competitor C":
            base = 38
            trend = 0.01  # 1% growth per month
        else:
            base = np.random.randint(35, 80)
            trend = np.random.uniform(0.01, 0.04)
        
        # Generate values with trend and noise
        values = []
        for i in range(len(months_str)):
            # Add trend
            value = base * (1 + trend) ** i
            
            # Add random noise
            noise = np.random.normal(0, 0.03)  # 3% random variation
            value *= (1 + noise)
            
            values.append(round(value, 1))
        
        df[competitor] = values
    
    return df

def generate_webinar_stats(competitors):
    """Generate sample webinar program statistics for competitors"""
    np.random.seed(42)
    
    stats = {
        'webinars_per_quarter': [3, 8, 5, 2][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(2, 10) for _ in competitors],
        'avg_attendees': [120, 350, 220, 85][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(80, 400) for _ in competitors],
        'attendance_rate': [48, 65, 58, 42][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(40, 70) for _ in competitors],
        'lead_conversion_rate': [12, 22, 18, 8][:len(competitors)] if len(competitors) <= 4 else [np.random.randint(8, 25) for _ in competitors],
    }
    
    return stats