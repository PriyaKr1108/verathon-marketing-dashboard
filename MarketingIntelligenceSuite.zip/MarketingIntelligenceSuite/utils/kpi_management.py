import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json

class KPIManager:
    """
    Class to manage and track marketing KPIs and KRAs.
    Handles metrics tracking, target setting, and performance monitoring.
    """
    
    def __init__(self):
        """Initialize the KPI Manager with default KPI categories and metrics"""
        # Define standard KPI categories and their metrics
        self.kpi_categories = {
            "digital_marketing": self._init_digital_marketing_kpis(),
            "webinar_performance": self._init_webinar_kpis(),
            "competitive_intelligence": self._init_competitive_kpis(),
            "content_marketing": self._init_content_kpis(),
            "roi_metrics": self._init_roi_kpis()
        }
        
        # Initialize KRA (Key Result Areas) tracking
        self.kras = self._init_kras()
        
        # Alert thresholds for KPIs
        self.alert_thresholds = self._init_alert_thresholds()

    def _init_digital_marketing_kpis(self):
        """Initialize digital marketing KPIs"""
        return {
            "website_traffic": {
                "description": "Total website visitors",
                "unit": "visits",
                "target": 15000,
                "current": 0,
                "trend": [],
                "frequency": "daily"
            },
            "conversion_rate": {
                "description": "Percentage of visitors who complete a desired action",
                "unit": "%",
                "target": 3.5,
                "current": 0,
                "trend": [],
                "frequency": "daily"
            },
            "cost_per_lead": {
                "description": "Average cost to acquire a lead",
                "unit": "$",
                "target": 90,
                "current": 0,
                "trend": [],
                "frequency": "weekly",
                "is_inverse": True  # Lower is better
            },
            "bounce_rate": {
                "description": "Percentage of visitors who navigate away after viewing only one page",
                "unit": "%",
                "target": 45,
                "current": 0,
                "trend": [],
                "frequency": "daily",
                "is_inverse": True  # Lower is better
            },
            "marketing_qualified_leads": {
                "description": "Number of leads that match marketing qualification criteria",
                "unit": "leads",
                "target": 500,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "sales_qualified_leads": {
                "description": "Number of leads that match sales qualification criteria",
                "unit": "leads",
                "target": 200,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "channel_effectiveness": {
                "description": "Performance metrics by marketing channel",
                "unit": "score",
                "target": 80,
                "current": 0,
                "trend": [],
                "frequency": "monthly",
                "breakdown": {
                    "organic_search": {"target": 85, "current": 0},
                    "paid_search": {"target": 75, "current": 0},
                    "social_media": {"target": 70, "current": 0},
                    "email": {"target": 80, "current": 0},
                    "referral": {"target": 65, "current": 0},
                    "direct": {"target": 70, "current": 0}
                }
            }
        }
    
    def _init_webinar_kpis(self):
        """Initialize webinar performance KPIs"""
        return {
            "registration_rate": {
                "description": "Percentage of invitees who register",
                "unit": "%",
                "target": 12,
                "current": 0,
                "trend": [],
                "frequency": "per webinar"
            },
            "attendance_rate": {
                "description": "Percentage of registrants who attend",
                "unit": "%",
                "target": 65,
                "current": 0,
                "trend": [],
                "frequency": "per webinar"
            },
            "engagement_score": {
                "description": "Measure of audience interaction during webinar",
                "unit": "score",
                "target": 8.0,
                "current": 0,
                "trend": [],
                "frequency": "per webinar",
                "max_value": 10
            },
            "lead_conversion_rate": {
                "description": "Percentage of attendees converted to leads",
                "unit": "%",
                "target": 25,
                "current": 0,
                "trend": [],
                "frequency": "per webinar"
            },
            "opportunity_conversion_rate": {
                "description": "Percentage of leads converted to opportunities",
                "unit": "%",
                "target": 15,
                "current": 0,
                "trend": [],
                "frequency": "per webinar"
            },
            "average_feedback_score": {
                "description": "Average attendee satisfaction rating",
                "unit": "score",
                "target": 4.5,
                "current": 0,
                "trend": [],
                "frequency": "per webinar",
                "max_value": 5
            },
            "content_relevance_score": {
                "description": "Attendee rating of content relevance",
                "unit": "score",
                "target": 4.3,
                "current": 0,
                "trend": [],
                "frequency": "per webinar",
                "max_value": 5
            }
        }
    
    def _init_competitive_kpis(self):
        """Initialize competitive intelligence KPIs"""
        return {
            "share_of_voice": {
                "description": "Brand's share of overall industry conversation",
                "unit": "%",
                "target": 25,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "competitive_position": {
                "description": "Market position relative to top competitors",
                "unit": "rank",
                "target": 1,
                "current": 0,
                "trend": [],
                "frequency": "quarterly",
                "is_inverse": True  # Lower is better
            },
            "relative_growth_rate": {
                "description": "Growth rate compared to industry average",
                "unit": "%",
                "target": 5,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            },
            "product_feature_parity": {
                "description": "Feature completeness compared to competitors",
                "unit": "%",
                "target": 110,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            },
            "seo_ranking_position": {
                "description": "Average position for target keywords",
                "unit": "position",
                "target": 3,
                "current": 0,
                "trend": [],
                "frequency": "monthly",
                "is_inverse": True  # Lower is better
            }
        }
    
    def _init_content_kpis(self):
        """Initialize content marketing KPIs"""
        return {
            "content_engagement": {
                "description": "Average engagement metrics across content pieces",
                "unit": "score",
                "target": 75,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "content_conversion_rate": {
                "description": "Conversion rate from content engagement",
                "unit": "%",
                "target": 5,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "social_sharing": {
                "description": "Average shares per content piece",
                "unit": "shares",
                "target": 120,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "content_download_rate": {
                "description": "Percentage of visitors who download gated content",
                "unit": "%",
                "target": 8,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            },
            "content_roi": {
                "description": "Return on investment for content marketing",
                "unit": "ratio",
                "target": 4.0,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            }
        }
    
    def _init_roi_kpis(self):
        """Initialize ROI measurement KPIs"""
        return {
            "marketing_roi": {
                "description": "Overall marketing return on investment",
                "unit": "ratio",
                "target": 5.0,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            },
            "customer_acquisition_cost": {
                "description": "Cost to acquire a new customer",
                "unit": "$",
                "target": 1000,
                "current": 0,
                "trend": [],
                "frequency": "monthly",
                "is_inverse": True  # Lower is better
            },
            "customer_lifetime_value": {
                "description": "Projected revenue from an average customer",
                "unit": "$",
                "target": 20000,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            },
            "clv_to_cac_ratio": {
                "description": "Ratio of customer lifetime value to acquisition cost",
                "unit": "ratio",
                "target": 3.0,
                "current": 0,
                "trend": [],
                "frequency": "quarterly"
            },
            "marketing_efficiency_ratio": {
                "description": "Revenue generated per marketing dollar spent",
                "unit": "ratio",
                "target": 7.0,
                "current": 0,
                "trend": [],
                "frequency": "monthly"
            }
        }
    
    def _init_kras(self):
        """Initialize Key Result Areas (KRAs)"""
        return {
            "market_expansion": {
                "description": "Expansion into new market segments",
                "metrics": ["new_segment_leads", "new_segment_conversions", "new_segment_revenue"],
                "target": 20,  # Percentage growth
                "current": 0,
                "frequency": "quarterly"
            },
            "product_adoption": {
                "description": "Adoption rate of key products",
                "metrics": ["product_demos", "trial_activations", "conversion_to_purchase"],
                "target": 25,  # Percentage adoption
                "current": 0,
                "frequency": "quarterly"
            },
            "brand_awareness": {
                "description": "Recognition and recall in target markets",
                "metrics": ["brand_mention_volume", "share_of_voice", "brand_search_volume"],
                "target": 35,  # Percentage increase
                "current": 0,
                "frequency": "quarterly"
            },
            "customer_satisfaction": {
                "description": "Overall customer satisfaction metrics",
                "metrics": ["nps_score", "customer_feedback_score", "retention_rate"],
                "target": 85,  # Score out of 100
                "current": 0,
                "frequency": "quarterly"
            },
            "digital_transformation": {
                "description": "Progress on digital marketing maturity",
                "metrics": ["automation_level", "data_integration", "personalization_capabilities"],
                "target": 80,  # Progress percentage
                "current": 0,
                "frequency": "quarterly"
            }
        }
    
    def _init_alert_thresholds(self):
        """Initialize alert thresholds for KPIs"""
        return {
            "critical": {
                "percentage_of_target": 70,  # Trigger alert if below 70% of target
                "trend_periods": 3,  # Number of consecutive declining periods
                "message": "Critical: KPI significantly below target"
            },
            "warning": {
                "percentage_of_target": 85,  # Trigger alert if below 85% of target
                "trend_periods": 2,  # Number of consecutive declining periods
                "message": "Warning: KPI trending below target"
            },
            "success": {
                "percentage_of_target": 110,  # Trigger notification if above 110% of target
                "message": "Success: KPI exceeding target"
            }
        }
    
    def update_kpi(self, category, kpi_name, value, timestamp=None):
        """
        Update a specific KPI with a new value
        
        Args:
            category (str): KPI category (e.g., 'digital_marketing')
            kpi_name (str): Name of the KPI to update
            value (float): New value for the KPI
            timestamp (datetime, optional): Timestamp for the update. Defaults to current time.
        
        Returns:
            bool: True if update successful, False otherwise
        """
        if category not in self.kpi_categories:
            return False
        
        if kpi_name not in self.kpi_categories[category]:
            return False
        
        # Set timestamp if not provided
        if timestamp is None:
            timestamp = datetime.now()
        
        # Update current value
        self.kpi_categories[category][kpi_name]["current"] = value
        
        # Add to trend data
        trend_entry = {
            "value": value,
            "timestamp": timestamp
        }
        self.kpi_categories[category][kpi_name]["trend"].append(trend_entry)
        
        # Limit trend list length to prevent excessive memory usage
        max_trend_entries = 100
        if len(self.kpi_categories[category][kpi_name]["trend"]) > max_trend_entries:
            self.kpi_categories[category][kpi_name]["trend"] = self.kpi_categories[category][kpi_name]["trend"][-max_trend_entries:]
        
        return True
    
    def update_kra(self, kra_name, value, timestamp=None):
        """
        Update a specific KRA with a new value
        
        Args:
            kra_name (str): Name of the KRA to update
            value (float): New value for the KRA
            timestamp (datetime, optional): Timestamp for the update. Defaults to current time.
        
        Returns:
            bool: True if update successful, False otherwise
        """
        if kra_name not in self.kras:
            return False
        
        # Set timestamp if not provided
        if timestamp is None:
            timestamp = datetime.now()
        
        # Update current value
        self.kras[kra_name]["current"] = value
        
        return True
    
    def get_kpi_status(self, category, kpi_name):
        """
        Get the current status of a KPI including performance against target
        
        Args:
            category (str): KPI category
            kpi_name (str): Name of the KPI
        
        Returns:
            dict: KPI status information or None if KPI not found
        """
        if category not in self.kpi_categories or kpi_name not in self.kpi_categories[category]:
            return None
        
        kpi = self.kpi_categories[category][kpi_name]
        
        # Calculate performance as percentage of target
        if kpi["target"] != 0:
            performance_pct = (kpi["current"] / kpi["target"]) * 100
        else:
            performance_pct = 0
        
        # Determine status based on thresholds
        if "is_inverse" in kpi and kpi["is_inverse"]:
            # For metrics where lower is better (inverse)
            if kpi["current"] <= kpi["target"] / self.alert_thresholds["success"]["percentage_of_target"] * 100:
                status = "success"
            elif kpi["current"] <= kpi["target"]:
                status = "good"
            elif kpi["current"] <= kpi["target"] * self.alert_thresholds["warning"]["percentage_of_target"] / 100:
                status = "warning"
            else:
                status = "critical"
        else:
            # For metrics where higher is better
            if performance_pct >= self.alert_thresholds["success"]["percentage_of_target"]:
                status = "success"
            elif performance_pct >= 100:
                status = "good"
            elif performance_pct >= self.alert_thresholds["warning"]["percentage_of_target"]:
                status = "warning"
            else:
                status = "critical"
        
        # Calculate trend direction
        trend_direction = "stable"
        if len(kpi["trend"]) >= 2:
            current = kpi["trend"][-1]["value"]
            previous = kpi["trend"][-2]["value"]
            
            if current > previous:
                trend_direction = "increasing"
            elif current < previous:
                trend_direction = "decreasing"
        
        return {
            "name": kpi_name,
            "description": kpi["description"],
            "current": kpi["current"],
            "target": kpi["target"],
            "unit": kpi["unit"],
            "performance_pct": performance_pct,
            "status": status,
            "trend_direction": trend_direction,
            "is_inverse": kpi.get("is_inverse", False)
        }
    
    def get_kra_status(self, kra_name):
        """
        Get the current status of a KRA including performance against target
        
        Args:
            kra_name (str): Name of the KRA
        
        Returns:
            dict: KRA status information or None if KRA not found
        """
        if kra_name not in self.kras:
            return None
        
        kra = self.kras[kra_name]
        
        # Calculate performance as percentage of target
        if kra["target"] != 0:
            performance_pct = (kra["current"] / kra["target"]) * 100
        else:
            performance_pct = 0
        
        # Determine status based on thresholds
        if performance_pct >= self.alert_thresholds["success"]["percentage_of_target"]:
            status = "success"
        elif performance_pct >= 100:
            status = "good"
        elif performance_pct >= self.alert_thresholds["warning"]["percentage_of_target"]:
            status = "warning"
        else:
            status = "critical"
        
        return {
            "name": kra_name,
            "description": kra["description"],
            "current": kra["current"],
            "target": kra["target"],
            "metrics": kra["metrics"],
            "performance_pct": performance_pct,
            "status": status,
            "frequency": kra["frequency"]
        }
    
    def get_all_kpi_statuses(self, category=None):
        """
        Get status of all KPIs, optionally filtered by category
        
        Args:
            category (str, optional): Category to filter by. Defaults to None.
        
        Returns:
            dict: Dictionary of KPI statuses
        """
        results = {}
        
        if category:
            if category not in self.kpi_categories:
                return {}
            categories = [category]
        else:
            categories = self.kpi_categories.keys()
        
        for cat in categories:
            results[cat] = {}
            for kpi_name in self.kpi_categories[cat]:
                results[cat][kpi_name] = self.get_kpi_status(cat, kpi_name)
        
        return results
    
    def get_all_kra_statuses(self):
        """
        Get status of all KRAs
        
        Returns:
            dict: Dictionary of KRA statuses
        """
        results = {}
        
        for kra_name in self.kras:
            results[kra_name] = self.get_kra_status(kra_name)
        
        return results
    
    def get_alerts(self):
        """
        Get all active alerts for KPIs that are below threshold
        
        Returns:
            list: List of alert dictionaries
        """
        alerts = []
        
        for category, kpis in self.kpi_categories.items():
            for kpi_name in kpis:
                status = self.get_kpi_status(category, kpi_name)
                
                if status["status"] == "critical":
                    alerts.append({
                        "level": "critical",
                        "message": f"{status['name']}: {self.alert_thresholds['critical']['message']}",
                        "kpi": status,
                        "category": category
                    })
                elif status["status"] == "warning":
                    alerts.append({
                        "level": "warning",
                        "message": f"{status['name']}: {self.alert_thresholds['warning']['message']}",
                        "kpi": status,
                        "category": category
                    })
                elif status["status"] == "success":
                    alerts.append({
                        "level": "success",
                        "message": f"{status['name']}: {self.alert_thresholds['success']['message']}",
                        "kpi": status,
                        "category": category
                    })
        
        return alerts
    
    def set_target(self, category, kpi_name, target_value):
        """
        Set a new target for a KPI
        
        Args:
            category (str): KPI category
            kpi_name (str): Name of the KPI
            target_value (float): New target value
        
        Returns:
            bool: True if update successful, False otherwise
        """
        if category not in self.kpi_categories or kpi_name not in self.kpi_categories[category]:
            return False
        
        self.kpi_categories[category][kpi_name]["target"] = target_value
        return True
    
    def set_kra_target(self, kra_name, target_value):
        """
        Set a new target for a KRA
        
        Args:
            kra_name (str): Name of the KRA
            target_value (float): New target value
        
        Returns:
            bool: True if update successful, False otherwise
        """
        if kra_name not in self.kras:
            return False
        
        self.kras[kra_name]["target"] = target_value
        return True
    
    def get_trend_data(self, category, kpi_name, period="all"):
        """
        Get trend data for a specific KPI
        
        Args:
            category (str): KPI category
            kpi_name (str): Name of the KPI
            period (str, optional): Time period to retrieve. Defaults to "all".
        
        Returns:
            list: List of trend data points or empty list if KPI not found
        """
        if category not in self.kpi_categories or kpi_name not in self.kpi_categories[category]:
            return []
        
        trend_data = self.kpi_categories[category][kpi_name]["trend"]
        
        # Filter by time period if needed
        if period != "all":
            now = datetime.now()
            
            if period == "week":
                start_date = now - timedelta(days=7)
            elif period == "month":
                start_date = now - timedelta(days=30)
            elif period == "quarter":
                start_date = now - timedelta(days=90)
            elif period == "year":
                start_date = now - timedelta(days=365)
            else:
                # Default to all data
                return trend_data
            
            filtered_data = [entry for entry in trend_data if entry["timestamp"] >= start_date]
            return filtered_data
        
        return trend_data
    
    def export_data(self, format="json"):
        """
        Export all KPI and KRA data
        
        Args:
            format (str, optional): Export format. Defaults to "json".
        
        Returns:
            str or dict: Exported data in the specified format
        """
        export_data = {
            "kpis": self.kpi_categories,
            "kras": self.kras,
            "export_date": datetime.now().isoformat()
        }
        
        if format.lower() == "json":
            # Convert datetime objects to strings for JSON serialization
            export_json = json.dumps(export_data, default=str)
            return export_json
        else:
            return export_data
    
    def import_data(self, data, format="json"):
        """
        Import KPI and KRA data
        
        Args:
            data (str or dict): Data to import
            format (str, optional): Import format. Defaults to "json".
        
        Returns:
            bool: True if import successful, False otherwise
        """
        try:
            if format.lower() == "json" and isinstance(data, str):
                imported_data = json.loads(data)
            else:
                imported_data = data
            
            if "kpis" in imported_data:
                self.kpi_categories = imported_data["kpis"]
            
            if "kras" in imported_data:
                self.kras = imported_data["kras"]
            
            return True
        except Exception as e:
            print(f"Error importing data: {e}")
            return False
    
    def get_suggested_actions(self, category, kpi_name):
        """
        Get AI-driven suggested actions for improving a specific KPI
        
        Args:
            category (str): KPI category
            kpi_name (str): Name of the KPI
        
        Returns:
            list: List of suggested actions
        """
        # This would integrate with an AI service in a real implementation
        # Here we provide static suggestions based on KPI category and name
        
        if category not in self.kpi_categories or kpi_name not in self.kpi_categories[category]:
            return []
        
        status = self.get_kpi_status(category, kpi_name)
        
        # Only provide suggestions for KPIs that need improvement
        if status["status"] not in ["warning", "critical"]:
            return []
        
        # Basic suggestions based on KPI type
        suggestions = []
        
        if category == "digital_marketing":
            if kpi_name == "website_traffic":
                suggestions = [
                    "Optimize top-performing pages for SEO",
                    "Increase paid search budget for high-converting keywords",
                    "Launch targeted social media campaign",
                    "Develop content addressing common industry pain points",
                    "Implement internal linking strategy for key pages"
                ]
            elif kpi_name == "conversion_rate":
                suggestions = [
                    "Conduct A/B testing on key landing pages",
                    "Optimize call-to-action placement and messaging",
                    "Improve page load speed for better user experience",
                    "Simplify form fields to reduce abandonment",
                    "Add social proof elements near conversion points"
                ]
            elif kpi_name == "cost_per_lead":
                suggestions = [
                    "Analyze channel performance and reallocate budget",
                    "Optimize underperforming paid campaigns",
                    "Implement lead scoring to focus on quality over quantity",
                    "Test new audience targeting parameters",
                    "Increase organic content production to reduce paid dependency"
                ]
        
        elif category == "webinar_performance":
            if kpi_name == "registration_rate":
                suggestions = [
                    "Refine webinar titles to emphasize value proposition",
                    "Test different promotional email subject lines",
                    "Expand promotion to additional channels",
                    "Create more targeted invitations by segment",
                    "Simplify registration process"
                ]
            elif kpi_name == "attendance_rate":
                suggestions = [
                    "Send additional reminder emails closer to the event",
                    "Add calendar invites with alerts to confirmation emails",
                    "Create pre-event engagement content to build anticipation",
                    "Offer incentives for live attendance",
                    "Schedule webinars at optimal times based on audience data"
                ]
            elif kpi_name == "engagement_score":
                suggestions = [
                    "Incorporate more interactive elements like polls and Q&A",
                    "Improve slide design for better visual engagement",
                    "Add real-world case studies and examples",
                    "Involve multiple speakers for variety",
                    "Break content into shorter, more focused segments"
                ]
        
        elif category == "competitive_intelligence":
            if kpi_name == "share_of_voice":
                suggestions = [
                    "Increase thought leadership content production",
                    "Expand presence at industry events and conferences",
                    "Develop a proactive PR strategy for industry publications",
                    "Partner with industry influencers for content collaboration",
                    "Increase social media engagement with industry conversations"
                ]
            elif kpi_name == "seo_ranking_position":
                suggestions = [
                    "Update content on high-potential keywords",
                    "Build quality backlinks from industry sources",
                    "Enhance technical SEO elements",
                    "Create linkable assets to attract natural links",
                    "Optimize for featured snippets on key search terms"
                ]
        
        return suggestions

def create_digital_marketing_report(kpi_manager, period="month"):
    """
    Create a comprehensive digital marketing performance report
    
    Args:
        kpi_manager (KPIManager): KPI manager instance
        period (str, optional): Time period for the report. Defaults to "month".
    
    Returns:
        dict: Report data
    """
    # Get all digital marketing KPIs
    digital_kpis = kpi_manager.get_all_kpi_statuses("digital_marketing")
    
    # Get trend data for key metrics
    traffic_trend = kpi_manager.get_trend_data("digital_marketing", "website_traffic", period)
    conversion_trend = kpi_manager.get_trend_data("digital_marketing", "conversion_rate", period)
    cpl_trend = kpi_manager.get_trend_data("digital_marketing", "cost_per_lead", period)
    
    # Calculate high-level metrics
    performing_well = sum(1 for kpi in digital_kpis["digital_marketing"].values() 
                          if kpi["status"] in ["good", "success"])
    needs_attention = sum(1 for kpi in digital_kpis["digital_marketing"].values() 
                          if kpi["status"] in ["warning", "critical"])
    
    # Get alerts
    alerts = [alert for alert in kpi_manager.get_alerts() 
              if alert["category"] == "digital_marketing"]
    
    # Compile report
    report = {
        "summary": {
            "metrics_performing_well": performing_well,
            "metrics_needing_attention": needs_attention,
            "alerts": alerts
        },
        "kpis": digital_kpis["digital_marketing"],
        "trends": {
            "website_traffic": traffic_trend,
            "conversion_rate": conversion_trend,
            "cost_per_lead": cpl_trend
        }
    }
    
    return report

def create_webinar_performance_report(kpi_manager, webinar_id=None):
    """
    Create a webinar performance report
    
    Args:
        kpi_manager (KPIManager): KPI manager instance
        webinar_id (str, optional): Specific webinar ID for individual report. 
                                    If None, creates overall program report.
    
    Returns:
        dict: Report data
    """
    # Get all webinar KPIs
    webinar_kpis = kpi_manager.get_all_kpi_statuses("webinar_performance")
    
    # Get trend data for key metrics
    registration_trend = kpi_manager.get_trend_data("webinar_performance", "registration_rate", "quarter")
    attendance_trend = kpi_manager.get_trend_data("webinar_performance", "attendance_rate", "quarter")
    engagement_trend = kpi_manager.get_trend_data("webinar_performance", "engagement_score", "quarter")
    
    # Calculate high-level metrics
    performing_well = sum(1 for kpi in webinar_kpis["webinar_performance"].values() 
                          if kpi["status"] in ["good", "success"])
    needs_attention = sum(1 for kpi in webinar_kpis["webinar_performance"].values() 
                          if kpi["status"] in ["warning", "critical"])
    
    # Get alerts
    alerts = [alert for alert in kpi_manager.get_alerts() 
              if alert["category"] == "webinar_performance"]
    
    # Get suggestions for improvement
    suggestions = []
    for kpi_name, kpi in webinar_kpis["webinar_performance"].items():
        if kpi["status"] in ["warning", "critical"]:
            kpi_suggestions = kpi_manager.get_suggested_actions("webinar_performance", kpi_name)
            if kpi_suggestions:
                suggestions.append({
                    "kpi": kpi_name,
                    "actions": kpi_suggestions
                })
    
    # Compile report
    report = {
        "summary": {
            "metrics_performing_well": performing_well,
            "metrics_needing_attention": needs_attention,
            "alerts": alerts
        },
        "kpis": webinar_kpis["webinar_performance"],
        "trends": {
            "registration_rate": registration_trend,
            "attendance_rate": attendance_trend,
            "engagement_score": engagement_trend
        },
        "improvement_suggestions": suggestions
    }
    
    return report

def get_crawl_walk_run_recommendations(kpi_manager):
    """
    Generate recommendations for transitioning between Crawl-Walk-Run stages
    based on current KPI performance
    
    Args:
        kpi_manager (KPIManager): KPI manager instance
    
    Returns:
        dict: Recommendations for each stage transition
    """
    # Get current webinar performance metrics
    webinar_kpis = kpi_manager.get_all_kpi_statuses("webinar_performance")
    
    # Count how many KPIs meet or exceed targets (good or success status)
    kpis_meeting_target = sum(1 for kpi in webinar_kpis["webinar_performance"].values() 
                              if kpi["status"] in ["good", "success"])
    
    # Total number of webinar KPIs
    total_webinar_kpis = len(webinar_kpis["webinar_performance"])
    
    # Calculate readiness percentage
    if total_webinar_kpis > 0:
        readiness_percentage = (kpis_meeting_target / total_webinar_kpis) * 100
    else:
        readiness_percentage = 0
    
    # Determine recommendations based on readiness
    recommendations = {
        "crawl_to_walk": {
            "ready": readiness_percentage >= 80,
            "readiness_score": readiness_percentage,
            "requirements_met": f"{kpis_meeting_target}/{total_webinar_kpis} KPIs",
            "next_steps": [],
            "focus_areas": []
        },
        "walk_to_run": {
            "ready": readiness_percentage >= 90,
            "readiness_score": readiness_percentage,
            "requirements_met": f"{kpis_meeting_target}/{total_webinar_kpis} KPIs",
            "next_steps": [],
            "focus_areas": []
        }
    }
    
    # Define next steps and focus areas based on readiness
    if readiness_percentage < 80:
        # Still in Crawl, working toward Walk
        recommendations["crawl_to_walk"]["next_steps"] = [
            "Improve webinar registration process and promotion",
            "Enhance content delivery and presenter training",
            "Implement basic engagement elements (polls, Q&A)",
            "Develop consistent follow-up process",
            "Standardize performance measurement"
        ]
        
        # Identify specific KPIs to focus on
        recommendations["crawl_to_walk"]["focus_areas"] = [
            f"Improve {kpi_name}: Currently at {kpi['current']}{kpi['unit']} vs. target of {kpi['target']}{kpi['unit']}"
            for kpi_name, kpi in webinar_kpis["webinar_performance"].items()
            if kpi["status"] in ["warning", "critical"]
        ]
    elif readiness_percentage < 90:
        # In Walk, working toward Run
        recommendations["walk_to_run"]["next_steps"] = [
            "Implement advanced segmentation and personalization",
            "Integrate fully with marketing automation and CRM",
            "Develop multi-touch attribution model",
            "Create advanced engagement measurement framework",
            "Implement predictive analytics for webinar optimization"
        ]
        
        # Identify specific KPIs to focus on
        recommendations["walk_to_run"]["focus_areas"] = [
            f"Optimize {kpi_name}: Currently at {kpi['current']}{kpi['unit']} vs. target of {kpi['target']}{kpi['unit']}"
            for kpi_name, kpi in webinar_kpis["webinar_performance"].items()
            if kpi["status"] in ["warning", "critical"]
        ]
    else:
        # Ready for Run stage
        recommendations["walk_to_run"]["next_steps"] = [
            "Implement AI-powered content recommendations",
            "Develop predictive lead scoring model",
            "Create dynamic webinar content personalization",
            "Establish advanced analytics dashboard",
            "Integrate with comprehensive customer journey mapping"
        ]
    
    return recommendations
