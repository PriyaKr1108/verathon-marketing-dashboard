import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from utils.competitive_intel import (
    fetch_competitive_data,
    generate_traffic_data,
    generate_domain_metrics,
    generate_digital_footprint,
    generate_seo_metrics,
    get_social_metrics,
    get_seo_performance,
    generate_webinar_stats
)

# Page configuration
st.set_page_config(
    page_title="Competitive Intelligence - Verathon",
    page_icon="🔍",
    layout="wide"
)

# Verathon brand colors
VERATHON_BLUE = "#0056A7"
VERATHON_WHITE = "#FFFFFF"

# Header
st.markdown(f'<h1 style="color:{VERATHON_BLUE};">Competitive Intelligence Hub</h1>', unsafe_allow_html=True)
st.markdown("Real-time competitor analysis and market positioning for Verathon")

# Sidebar filters
st.sidebar.header("Analysis Configuration")

# Competitor selection
default_competitors = ["Verathon", "Competitor A", "Competitor B", "Competitor C"]
selected_competitors = st.sidebar.multiselect(
    "Select Competitors to Analyze",
    options=["Verathon", "Competitor A", "Competitor B", "Competitor C", "Competitor D", "Competitor E"],
    default=default_competitors
)

# Time period selection
timeframe = st.sidebar.selectbox(
    "Analysis Timeframe",
    options=["Last 30 Days", "Last 90 Days", "Last 6 Months", "Last Year", "Custom Range"],
    index=1
)

# Market segment focus
market_segment = st.sidebar.selectbox(
    "Market Segment Focus",
    options=["All Segments", "Hospital Systems", "Outpatient Clinics", "Emergency Care", "Private Practices"],
    index=0
)

# Analysis type
analysis_type = st.sidebar.radio(
    "Analysis Type",
    options=["Comprehensive", "Digital Presence", "Content Strategy", "Webinar & Events", "Technology Stack", "Customer Experience"]
)

# Button to refresh data
if st.sidebar.button("Refresh Competitive Data"):
    st.sidebar.success("Data refreshed successfully!")

# Main content
if not selected_competitors:
    st.warning("Please select at least one competitor to analyze.")
else:
    # Fetch competitive data
    competitive_data = fetch_competitive_data(selected_competitors, timeframe)
    
    # Overview section
    st.header("Competitive Landscape Overview")
    
    # Market position visualization
    st.subheader("Market Position Analysis")
    
    # Create data for radar chart
    radar_data = generate_digital_footprint(selected_competitors)
    dimensions = list(radar_data[selected_competitors[0]].keys())
    
    # Create the radar chart
    fig = go.Figure()
    
    # Add traces for each competitor
    colors = [VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8", "#CFE2F3", "#EFF5FB"]
    for i, competitor in enumerate(selected_competitors):
        fig.add_trace(go.Scatterpolar(
            r=[radar_data[competitor][dim] for dim in dimensions],
            theta=dimensions,
            fill='toself',
            name=competitor,
            line_color=colors[i % len(colors)],
            opacity=0.7
        ))
    
    # Update layout
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 10]
            )
        ),
        showlegend=True,
        height=500
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Key metrics comparison
    st.subheader("Key Digital Marketing Metrics")
    
    # Gather metrics for comparison
    domain_metrics = generate_domain_metrics(selected_competitors)
    metrics_df = pd.DataFrame(domain_metrics)
    metrics_df.set_index('Competitor', inplace=True)
    
    # Create a metrics comparison table with conditional formatting
    def highlight_max(s):
        is_max = s == s.max()
        return ['background-color: rgba(0, 86, 167, 0.2)' if v else '' for v in is_max]
    
    def highlight_verathon(df):
        return ['background-color: rgba(0, 86, 167, 0.1)' if df.index[i] == 'Verathon' else '' for i in range(len(df))]
    
    styled_metrics = metrics_df.style.apply(highlight_max).apply(highlight_verathon, axis=1)
    
    st.dataframe(styled_metrics, use_container_width=True)
    
    # Traffic trends
    st.subheader("Website Traffic Trends")
    
    traffic_data = generate_traffic_data(selected_competitors, timeframe)
    
    # Create line chart for traffic trends
    traffic_fig = px.line(
        traffic_data, 
        x="Month", 
        y=selected_competitors,
        markers=True,
        labels={"value": "Monthly Visitors", "variable": "Competitor"},
        title="Monthly Website Traffic Comparison",
        color_discrete_map={comp: colors[i % len(colors)] for i, comp in enumerate(selected_competitors)}
    )
    
    traffic_fig.update_layout(
        xaxis_title="Month",
        yaxis_title="Monthly Visitors",
        legend_title="Competitor",
        height=400
    )
    
    st.plotly_chart(traffic_fig, use_container_width=True)
    
    # Detailed analysis sections
    tabs = st.tabs(["Digital Presence", "SEO Performance", "Social Media", "Content Strategy", "Webinar Programs", "Technology"])
    
    with tabs[0]:
        st.subheader("Digital Presence Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Channel distribution
            channel_data = pd.DataFrame({
                'Competitor': [],
                'Channel': [],
                'Percentage': []
            })
            
            channels = ['Organic Search', 'Paid Search', 'Social', 'Direct', 'Referral', 'Email']
            
            for competitor in selected_competitors:
                # Generate random but realistic channel distributions
                np.random.seed(hash(competitor) % 10000)
                values = np.random.dirichlet(np.ones(len(channels)) * 2, size=1)[0]
                values = [round(v * 100, 1) for v in values]
                
                # Adjust Verathon to show weakness in social
                if competitor == 'Verathon':
                    idx = channels.index('Social')
                    values[idx] = values[idx] * 0.6
                    idx = channels.index('Organic Search')
                    values[idx] = values[idx] * 1.2
                    # Normalize to 100%
                    total = sum(values)
                    values = [round(v * 100 / total, 1) for v in values]
                
                temp_df = pd.DataFrame({
                    'Competitor': [competitor] * len(channels),
                    'Channel': channels,
                    'Percentage': values
                })
                
                channel_data = pd.concat([channel_data, temp_df])
            
            channel_fig = px.bar(
                channel_data,
                x='Competitor',
                y='Percentage',
                color='Channel',
                title="Traffic Source Distribution",
                barmode='stack',
                color_discrete_sequence=px.colors.qualitative.Plotly
            )
            
            channel_fig.update_layout(height=400)
            st.plotly_chart(channel_fig, use_container_width=True)
        
        with col2:
            # Device distribution
            device_data = pd.DataFrame({
                'Competitor': [],
                'Device': [],
                'Percentage': []
            })
            
            devices = ['Desktop', 'Mobile', 'Tablet']
            
            for competitor in selected_competitors:
                np.random.seed(hash(competitor) % 10000 + 1)
                if competitor == 'Verathon':
                    values = [60, 35, 5]  # Verathon skews desktop
                else:
                    values = np.random.dirichlet(np.ones(len(devices)), size=1)[0]
                    values = [round(v * 100, 1) for v in values]
                
                temp_df = pd.DataFrame({
                    'Competitor': [competitor] * len(devices),
                    'Device': devices,
                    'Percentage': values
                })
                
                device_data = pd.concat([device_data, temp_df])
            
            device_fig = px.bar(
                device_data,
                x='Competitor',
                y='Percentage',
                color='Device',
                title="Device Distribution",
                barmode='stack',
                color_discrete_sequence=[VERATHON_BLUE, "#6FA8DC", "#CFE2F3"]
            )
            
            device_fig.update_layout(height=400)
            st.plotly_chart(device_fig, use_container_width=True)
        
        # Engagement metrics
        st.subheader("Engagement Metrics Comparison")
        
        engagement_data = pd.DataFrame({
            'Competitor': selected_competitors,
            'Pages/Session': [3.2, 4.1, 3.5, 2.9] if len(selected_competitors) == 4 else [round(np.random.uniform(2.5, 4.5), 1) for _ in selected_competitors],
            'Avg. Session Duration (min)': [2.8, 3.5, 3.2, 2.3] if len(selected_competitors) == 4 else [round(np.random.uniform(1.5, 4.0), 1) for _ in selected_competitors],
            'Bounce Rate (%)': [56, 42, 48, 62] if len(selected_competitors) == 4 else [round(np.random.uniform(35, 65), 0) for _ in selected_competitors]
        })
        
        # Create grouped bar chart for engagement metrics
        engagement_melted = pd.melt(
            engagement_data, 
            id_vars=['Competitor'], 
            value_vars=['Pages/Session', 'Avg. Session Duration (min)', 'Bounce Rate (%)'],
            var_name='Metric', 
            value_name='Value'
        )
        
        engagement_fig = px.bar(
            engagement_melted,
            x='Competitor',
            y='Value',
            color='Metric',
            barmode='group',
            title="Engagement Metrics by Competitor",
            color_discrete_sequence=[VERATHON_BLUE, "#6FA8DC", "#CFE2F3"]
        )
        
        engagement_fig.update_layout(height=500)
        st.plotly_chart(engagement_fig, use_container_width=True)
        
    with tabs[1]:
        st.subheader("SEO Performance")
        
        seo_metrics = generate_seo_metrics(selected_competitors)
        seo_performance = get_seo_performance(selected_competitors)
        
        seo_col1, seo_col2 = st.columns(2)
        
        with seo_col1:
            # Keyword visibility chart
            keyword_fig = px.bar(
                seo_metrics,
                x='Competitor',
                y=['Top 3 Keywords', 'Top 10 Keywords', 'Top 100 Keywords'],
                title="Keyword Ranking Distribution",
                barmode='group',
                color_discrete_sequence=[VERATHON_BLUE, "#6FA8DC", "#CFE2F3"]
            )
            
            keyword_fig.update_layout(height=400)
            st.plotly_chart(keyword_fig, use_container_width=True)
        
        with seo_col2:
            # Domain authority comparison
            auth_fig = px.bar(
                seo_metrics,
                x='Competitor',
                y='Domain Authority',
                title="Domain Authority Comparison",
                color='Competitor',
                color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
            )
            
            auth_fig.update_layout(height=400)
            st.plotly_chart(auth_fig, use_container_width=True)
        
        # SEO performance trends
        st.subheader("Organic Search Visibility Trends")
        
        seo_trend_fig = px.line(
            seo_performance,
            x='Month',
            y=selected_competitors,
            markers=True,
            title="Organic Visibility Score Trends",
            color_discrete_map={comp: colors[i % len(colors)] for i, comp in enumerate(selected_competitors)}
        )
        
        seo_trend_fig.update_layout(height=400)
        st.plotly_chart(seo_trend_fig, use_container_width=True)
        
        # Keyword gap analysis
        st.subheader("Keyword Gap Analysis")
        
        # Create a sample keyword gap analysis table
        keyword_gaps = pd.DataFrame({
            'Keyword': ['medical device solutions', 'healthcare imaging', 'portable ultrasound', 'medical diagnostics', 'patient monitoring systems'],
            'Monthly Search Volume': [3600, 6500, 4800, 8900, 5200],
            'Verathon Position': [15, 28, 8, 'Not Ranked', 42],
            'Competitor A Position': [3, 5, 2, 12, 7],
            'Competitor B Position': [8, 12, 4, 8, 15],
            'Competitor C Position': [25, 'Not Ranked', 18, 5, 9],
            'Difficulty (1-100)': [62, 72, 58, 65, 48]
        })
        
        st.dataframe(keyword_gaps, use_container_width=True, hide_index=True)
        
    with tabs[2]:
        st.subheader("Social Media Analysis")
        
        social_metrics = get_social_metrics(selected_competitors)
        
        # Followers by platform visualization
        social_fig = px.bar(
            social_metrics,
            x='Competitor',
            y=['LinkedIn Followers', 'Twitter Followers', 'Facebook Followers', 'Instagram Followers'],
            title="Social Media Followers by Platform",
            barmode='group',
            log_y=True,  # Use log scale for better visualization
            color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
        )
        
        social_fig.update_layout(height=500)
        st.plotly_chart(social_fig, use_container_width=True)
        
        # Engagement rates comparison
        st.subheader("Social Media Engagement Rate Comparison")
        
        engagement_df = pd.DataFrame({
            'Competitor': selected_competitors,
            'LinkedIn Engagement Rate (%)': [0.9, 2.1, 1.5, 0.8] if len(selected_competitors) == 4 else [round(np.random.uniform(0.5, 2.5), 1) for _ in selected_competitors],
            'Twitter Engagement Rate (%)': [0.5, 1.2, 0.8, 0.4] if len(selected_competitors) == 4 else [round(np.random.uniform(0.2, 1.5), 1) for _ in selected_competitors],
            'Facebook Engagement Rate (%)': [0.7, 1.5, 1.1, 0.6] if len(selected_competitors) == 4 else [round(np.random.uniform(0.4, 2.0), 1) for _ in selected_competitors]
        })
        
        # Melt the dataframe for better visualization
        engagement_melted = pd.melt(
            engagement_df,
            id_vars=['Competitor'],
            var_name='Platform',
            value_name='Engagement Rate (%)'
        )
        
        # Create a heatmap of engagement rates
        engagement_heatmap = px.density_heatmap(
            engagement_melted,
            x='Competitor',
            y='Platform',
            z='Engagement Rate (%)',
            color_continuous_scale=['#EFF5FB', '#CFE2F3', '#9FC5E8', '#6FA8DC', '#3C78D8', VERATHON_BLUE],
            title="Social Media Engagement Rates"
        )
        
        engagement_heatmap.update_layout(height=400)
        st.plotly_chart(engagement_heatmap, use_container_width=True)
        
        # Content type analysis
        st.subheader("Content Type Distribution")
        
        # Create sample data for content type distribution
        content_types = ['Product Updates', 'Industry News', 'Educational Content', 'Case Studies', 'Company News']
        content_data = pd.DataFrame({
            'Competitor': [],
            'Content Type': [],
            'Percentage': []
        })
        
        for competitor in selected_competitors:
            # Generate different distributions for competitors
            if competitor == 'Verathon':
                values = [45, 10, 20, 15, 10]  # Verathon focuses heavily on product updates
            elif competitor == 'Competitor A':
                values = [25, 15, 35, 20, 5]   # Competitor A focuses on educational content
            elif competitor == 'Competitor B':
                values = [30, 20, 15, 25, 10]  # Competitor B balances product and case studies
            else:
                np.random.seed(hash(competitor) % 10000 + 2)
                values = np.random.dirichlet(np.ones(len(content_types)), size=1)[0]
                values = [round(v * 100, 1) for v in values]
            
            temp_df = pd.DataFrame({
                'Competitor': [competitor] * len(content_types),
                'Content Type': content_types,
                'Percentage': values
            })
            
            content_data = pd.concat([content_data, temp_df])
        
        content_fig = px.bar(
            content_data,
            x='Competitor',
            y='Percentage',
            color='Content Type',
            title="Content Type Distribution on Social Media",
            barmode='stack',
            color_discrete_sequence=px.colors.qualitative.Plotly
        )
        
        content_fig.update_layout(height=500)
        st.plotly_chart(content_fig, use_container_width=True)
        
    with tabs[3]:
        st.subheader("Content Strategy Analysis")
        
        # Content production rate comparison
        content_prod = pd.DataFrame({
            'Competitor': selected_competitors,
            'Blog Posts (Monthly)': [3, 8, 5, 2] if len(selected_competitors) == 4 else [round(np.random.uniform(1, 10), 0) for _ in selected_competitors],
            'Whitepapers (Quarterly)': [1, 4, 2, 1] if len(selected_competitors) == 4 else [round(np.random.uniform(0, 5), 0) for _ in selected_competitors],
            'Case Studies (Quarterly)': [2, 5, 3, 1] if len(selected_competitors) == 4 else [round(np.random.uniform(0, 6), 0) for _ in selected_competitors],
            'Videos (Monthly)': [1, 6, 3, 0] if len(selected_competitors) == 4 else [round(np.random.uniform(0, 8), 0) for _ in selected_competitors]
        })
        
        # Create a bubble chart for content production
        content_melted = pd.melt(
            content_prod,
            id_vars=['Competitor'],
            var_name='Content Type',
            value_name='Production Rate'
        )
        
        # Add a size column proportional to production rate
        content_melted['Size'] = content_melted['Production Rate'] * 10
        
        content_bubble = px.scatter(
            content_melted,
            x='Competitor',
            y='Content Type',
            size='Size',
            color='Competitor',
            title="Content Production Rate Comparison",
            size_max=50,
            color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
        )
        
        content_bubble.update_layout(height=500)
        st.plotly_chart(content_bubble, use_container_width=True)
        
        # Content engagement metrics
        content_engagement = pd.DataFrame({
            'Competitor': selected_competitors,
            'Avg. Time on Page (min)': [2.1, 3.4, 2.8, 1.9] if len(selected_competitors) == 4 else [round(np.random.uniform(1.5, 4.0), 1) for _ in selected_competitors],
            'Social Shares per Content': [18, 75, 42, 12] if len(selected_competitors) == 4 else [round(np.random.uniform(10, 100), 0) for _ in selected_competitors],
            'Lead Generation Rate (%)': [2.3, 5.8, 3.7, 1.8] if len(selected_competitors) == 4 else [round(np.random.uniform(1.0, 7.0), 1) for _ in selected_competitors]
        })
        
        # Create radar chart for content engagement
        content_radar_fig = go.Figure()
        
        # Normalize data for radar chart
        max_time = content_engagement['Avg. Time on Page (min)'].max()
        max_shares = content_engagement['Social Shares per Content'].max()
        max_lead = content_engagement['Lead Generation Rate (%)'].max()
        
        for i, competitor in enumerate(selected_competitors):
            row = content_engagement[content_engagement['Competitor'] == competitor].iloc[0]
            content_radar_fig.add_trace(go.Scatterpolar(
                r=[
                    row['Avg. Time on Page (min)'] / max_time * 10,
                    row['Social Shares per Content'] / max_shares * 10,
                    row['Lead Generation Rate (%)'] / max_lead * 10
                ],
                theta=['Time on Page', 'Social Shares', 'Lead Generation'],
                fill='toself',
                name=competitor,
                line_color=colors[i % len(colors)]
            ))
        
        content_radar_fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 10]
                )
            ),
            title="Content Engagement Metrics (Normalized)",
            showlegend=True,
            height=500
        )
        
        st.plotly_chart(content_radar_fig, use_container_width=True)
        
        # Topic focus analysis
        st.subheader("Content Topic Focus Analysis")
        
        # Create sample data for topic distribution
        topics = ['Product Features', 'Industry Trends', 'Clinical Research', 'Customer Success', 'Technology Innovation']
        topic_data = pd.DataFrame({
            'Competitor': [],
            'Topic': [],
            'Emphasis Score (1-10)': []
        })
        
        for competitor in selected_competitors:
            # Generate different distributions for competitors
            if competitor == 'Verathon':
                values = [9, 5, 6, 7, 4]  # Verathon focuses heavily on product features
            elif competitor == 'Competitor A':
                values = [6, 8, 9, 7, 8]   # Competitor A focuses on research and trends
            elif competitor == 'Competitor B':
                values = [7, 6, 8, 8, 7]  # Competitor B is balanced
            else:
                np.random.seed(hash(competitor) % 10000 + 3)
                values = [round(np.random.uniform(3, 9), 0) for _ in range(len(topics))]
            
            temp_df = pd.DataFrame({
                'Competitor': [competitor] * len(topics),
                'Topic': topics,
                'Emphasis Score (1-10)': values
            })
            
            topic_data = pd.concat([topic_data, temp_df])
        
        topic_heatmap = px.density_heatmap(
            topic_data,
            x='Topic',
            y='Competitor',
            z='Emphasis Score (1-10)',
            color_continuous_scale=['#EFF5FB', '#CFE2F3', '#9FC5E8', '#6FA8DC', '#3C78D8', VERATHON_BLUE],
            title="Content Topic Focus Heatmap"
        )
        
        topic_heatmap.update_layout(height=400)
        st.plotly_chart(topic_heatmap, use_container_width=True)
        
    with tabs[4]:
        st.subheader("Webinar Program Analysis")
        
        webinar_stats = generate_webinar_stats(selected_competitors)
        
        # Create comprehensive comparison
        webinar_comparison = pd.DataFrame({
            'Competitor': selected_competitors,
            'Webinars per Quarter': webinar_stats['webinars_per_quarter'],
            'Avg. Attendees': webinar_stats['avg_attendees'],
            'Attendance Rate (%)': webinar_stats['attendance_rate'],
            'Lead Conversion Rate (%)': webinar_stats['lead_conversion_rate'],
        })
        
        # Show the comparison table
        st.dataframe(webinar_comparison, use_container_width=True, hide_index=True)
        
        # Create visualization for webinar frequency and attendance
        webinar_col1, webinar_col2 = st.columns(2)
        
        with webinar_col1:
            # Webinar frequency
            freq_fig = px.bar(
                webinar_comparison,
                x='Competitor',
                y='Webinars per Quarter',
                color='Competitor',
                title="Webinar Frequency (Quarterly)",
                color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
            )
            
            freq_fig.update_layout(height=400)
            st.plotly_chart(freq_fig, use_container_width=True)
        
        with webinar_col2:
            # Webinar attendance
            attend_fig = px.bar(
                webinar_comparison,
                x='Competitor',
                y='Avg. Attendees',
                color='Competitor',
                title="Average Webinar Attendance",
                color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
            )
            
            attend_fig.update_layout(height=400)
            st.plotly_chart(attend_fig, use_container_width=True)
        
        # Webinar effectiveness metrics
        st.subheader("Webinar Effectiveness Metrics")
        
        # Create a scatter plot comparing attendance rate and lead conversion
        effect_fig = px.scatter(
            webinar_comparison,
            x='Attendance Rate (%)',
            y='Lead Conversion Rate (%)',
            size='Avg. Attendees',
            color='Competitor',
            title="Webinar Effectiveness Matrix",
            size_max=60,
            text='Competitor',
            color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
        )
        
        effect_fig.update_layout(height=500)
        st.plotly_chart(effect_fig, use_container_width=True)
        
        # Webinar topic comparison
        st.subheader("Webinar Topic Analysis")
        
        # Create sample data for webinar topics
        webinar_topics = ['Product Demonstrations', 'Clinical Applications', 'Industry Trends', 'Customer Success Stories', 'Technical Training']
        topic_data = pd.DataFrame({
            'Competitor': [],
            'Topic': [],
            'Percentage': []
        })
        
        for competitor in selected_competitors:
            # Generate different distributions for competitors
            if competitor == 'Verathon':
                values = [50, 20, 10, 10, 10]  # Verathon focuses heavily on product demos
            elif competitor == 'Competitor A':
                values = [20, 40, 15, 15, 10]   # Competitor A focuses on clinical applications
            elif competitor == 'Competitor B':
                values = [25, 25, 20, 10, 20]  # Competitor B balances demos and clinical applications
            else:
                np.random.seed(hash(competitor) % 10000 + 4)
                values = np.random.dirichlet(np.ones(len(webinar_topics)), size=1)[0]
                values = [round(v * 100, 1) for v in values]
            
            temp_df = pd.DataFrame({
                'Competitor': [competitor] * len(webinar_topics),
                'Topic': webinar_topics,
                'Percentage': values
            })
            
            topic_data = pd.concat([topic_data, temp_df])
        
        # Create stacked bar chart for topic distribution
        topic_fig = px.bar(
            topic_data,
            x='Competitor',
            y='Percentage',
            color='Topic',
            title="Webinar Topic Distribution",
            barmode='stack',
            color_discrete_sequence=px.colors.qualitative.Plotly
        )
        
        topic_fig.update_layout(height=500)
        st.plotly_chart(topic_fig, use_container_width=True)
        
    with tabs[5]:
        st.subheader("Technology Stack Analysis")
        
        # Create sample data for technology stacks
        tech_categories = ['Marketing Automation', 'Analytics', 'CMS', 'CRM', 'E-commerce', 'Social Media Management']
        
        tech_data = {
            'Verathon': {
                'Marketing Automation': 'Marketo',
                'Analytics': 'Google Analytics',
                'CMS': 'WordPress',
                'CRM': 'Salesforce',
                'E-commerce': 'Custom Solution',
                'Social Media Management': 'Hootsuite'
            },
            'Competitor A': {
                'Marketing Automation': 'HubSpot',
                'Analytics': 'Adobe Analytics',
                'CMS': 'Drupal',
                'CRM': 'Salesforce',
                'E-commerce': 'Magento',
                'Social Media Management': 'Sprout Social'
            },
            'Competitor B': {
                'Marketing Automation': 'Pardot',
                'Analytics': 'Google Analytics',
                'CMS': 'Sitecore',
                'CRM': 'Microsoft Dynamics',
                'E-commerce': 'Shopify',
                'Social Media Management': 'Buffer'
            },
            'Competitor C': {
                'Marketing Automation': 'HubSpot',
                'Analytics': 'Google Analytics',
                'CMS': 'WordPress',
                'CRM': 'HubSpot CRM',
                'E-commerce': 'WooCommerce',
                'Social Media Management': 'Hootsuite'
            }
        }
        
        # Filter tech data for selected competitors
        filtered_tech_data = {comp: tech_data.get(comp, {}) for comp in selected_competitors if comp in tech_data}
        
        # Create a comparison table
        tech_rows = []
        for category in tech_categories:
            row = {'Category': category}
            for comp in selected_competitors:
                if comp in filtered_tech_data:
                    row[comp] = filtered_tech_data[comp].get(category, 'Unknown')
                else:
                    row[comp] = 'Unknown'
            tech_rows.append(row)
        
        tech_df = pd.DataFrame(tech_rows)
        st.dataframe(tech_df, use_container_width=True, hide_index=True)
        
        # Technology sophistication radar chart
        st.subheader("Technology Sophistication Analysis")
        
        # Create sophistication scores (1-10 scale)
        tech_scores = pd.DataFrame({
            'Competitor': [],
            'Category': [],
            'Sophistication Score (1-10)': []
        })
        
        for competitor in selected_competitors:
            if competitor == 'Verathon':
                scores = [7, 6, 5, 8, 5, 6]  # Verathon's tech sophistication scores
            elif competitor == 'Competitor A':
                scores = [9, 8, 7, 8, 8, 8]  # Competitor A is more sophisticated
            elif competitor == 'Competitor B':
                scores = [8, 7, 9, 7, 6, 7]  # Competitor B has strong CMS
            elif competitor == 'Competitor C':
                scores = [6, 6, 5, 6, 5, 6]  # Competitor C is less sophisticated
            else:
                np.random.seed(hash(competitor) % 10000 + 5)
                scores = [round(np.random.uniform(4, 9), 0) for _ in range(len(tech_categories))]
            
            temp_df = pd.DataFrame({
                'Competitor': [competitor] * len(tech_categories),
                'Category': tech_categories,
                'Sophistication Score (1-10)': scores
            })
            
            tech_scores = pd.concat([tech_scores, temp_df])
        
        # Create a radar chart for technology sophistication
        tech_fig = px.line_polar(
            tech_scores,
            r='Sophistication Score (1-10)',
            theta='Category',
            color='Competitor',
            line_close=True,
            color_discrete_sequence=[VERATHON_BLUE, "#3C78D8", "#6FA8DC", "#9FC5E8"]
        )
        
        tech_fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 10]
                )
            ),
            height=500
        )
        
        st.plotly_chart(tech_fig, use_container_width=True)
        
        # Integration level heatmap
        st.subheader("Technology Integration Level")
        
        # Create integration level data (1-10 scale, higher is better)
        integration_data = pd.DataFrame({
            'Competitor': selected_competitors,
            'Cross-Platform Integration': [5, 8, 7, 5] if len(selected_competitors) == 4 else [round(np.random.uniform(4, 9), 0) for _ in selected_competitors],
            'Data Flow Automation': [6, 9, 7, 4] if len(selected_competitors) == 4 else [round(np.random.uniform(4, 9), 0) for _ in selected_competitors],
            'Analytics Integration': [7, 8, 6, 5] if len(selected_competitors) == 4 else [round(np.random.uniform(4, 9), 0) for _ in selected_competitors],
            'Unified Customer View': [5, 9, 6, 4] if len(selected_competitors) == 4 else [round(np.random.uniform(4, 9), 0) for _ in selected_competitors]
        })
        
        # Melt for heatmap
        integration_melted = pd.melt(
            integration_data,
            id_vars=['Competitor'],
            var_name='Integration Type',
            value_name='Level (1-10)'
        )
        
        integration_heatmap = px.density_heatmap(
            integration_melted,
            x='Integration Type',
            y='Competitor',
            z='Level (1-10)',
            color_continuous_scale=['#EFF5FB', '#CFE2F3', '#9FC5E8', '#6FA8DC', '#3C78D8', VERATHON_BLUE],
            title="Technology Integration Level"
        )
        
        integration_heatmap.update_layout(height=400)
        st.plotly_chart(integration_heatmap, use_container_width=True)
    
    # Competitive Gap Analysis
    st.header("Strategic Gap Analysis")
    
    st.markdown("""
    Based on our competitive analysis, we've identified key areas where Verathon can gain strategic advantage 
    through Digital Factory 24's marketing solutions.
    """)
    
    gap_col1, gap_col2 = st.columns(2)
    
    with gap_col1:
        st.subheader("Identified Competitive Gaps")
        
        # Create gap analysis data
        gap_data = pd.DataFrame({
            'Category': ['Social Media Presence', 'Content Strategy', 'SEO Performance', 'Webinar Engagement', 'Technology Integration'],
            'Gap Severity': [8, 6, 7, 5, 6],  # 1-10 scale, higher is bigger gap
            'Competitive Position': [3, 4, 3, 2, 3],  # Ranking among competitors (1 = best)
            'Opportunity Size': [9, 7, 8, 7, 8]  # 1-10 scale, higher is bigger opportunity
        })
        
        # Create a bubble chart for gap analysis
        gap_fig = px.scatter(
            gap_data,
            x='Gap Severity',
            y='Opportunity Size',
            size='Gap Severity',
            color='Category',
            text='Category',
            size_max=60,
            title="Competitive Gap Analysis"
        )
        
        gap_fig.update_layout(
            xaxis=dict(
                title="Gap Severity (1-10)",
                range=[0, 10]
            ),
            yaxis=dict(
                title="Opportunity Size (1-10)",
                range=[0, 10]
            ),
            height=500
        )
        
        st.plotly_chart(gap_fig, use_container_width=True)
    
    with gap_col2:
        st.subheader("Recommended Priority Focus Areas")
        
        # Create priority recommendations based on gap analysis
        st.markdown("""
        #### 1. Social Media Strategy Enhancement
        
        Verathon's social media presence lags significantly behind Competitors A and B, particularly in engagement rates 
        and content diversity. Digital Factory 24 recommends a complete social media revitalization with:
        
        - Enhanced content calendar focusing on educational and thought leadership content
        - Increased posting frequency with optimized timing
        - Advanced audience targeting and segmentation
        - Integration with webinar promotion strategy
        
        #### 2. SEO Performance Optimization
        
        Current keyword rankings show significant opportunities for improvement, especially for high-volume industry 
        terms. Our comprehensive SEO strategy includes:
        
        - Technical SEO audit and implementation
        - Content gap analysis and creation
        - Strategic backlink acquisition
        - Enhanced product page optimization
        
        #### 3. Technology Integration
        
        Verathon's technology stack shows limited integration compared to top competitors, creating data silos and 
        inefficient workflows. Digital Factory 24 proposes:
        
        - Marketing technology audit and roadmap development
        - Custom integration solutions for existing platforms
        - Enhanced data flow automation
        - Unified customer data platform implementation
        """)
    
    # Strategic Recommendations
    st.header("Strategic Recommendations & Implementation Plan")
    
    st.markdown("""
    Digital Factory 24 has developed a comprehensive action plan to address the identified competitive gaps 
    and leverage Verathon's strengths in the market.
    """)
    
    # Create a Gantt chart for implementation timeline
    implementation_tasks = [
        dict(Task="Social Media Strategy Revamp", Start='2025-04-15', Finish='2025-05-30', Resource="High"),
        dict(Task="Content Marketing Enhancement", Start='2025-05-01', Finish='2025-06-30', Resource="Medium"),
        dict(Task="SEO Performance Optimization", Start='2025-04-10', Finish='2025-07-15', Resource="High"),
        dict(Task="Technology Stack Integration", Start='2025-05-15', Finish='2025-08-30', Resource="High"),
        dict(Task="Webinar Program Enhancement", Start='2025-06-01', Finish='2025-07-30', Resource="Medium"),
        dict(Task="Competitive Monitoring System", Start='2025-04-05', Finish='2025-05-15', Resource="Low")
    ]
    
    implementation_df = pd.DataFrame(implementation_tasks)
    
    # Convert dates to datetime
    implementation_df['Start'] = pd.to_datetime(implementation_df['Start'])
    implementation_df['Finish'] = pd.to_datetime(implementation_df['Finish'])
    
    # Create a column for the duration of each task
    implementation_df['Duration'] = implementation_df['Finish'] - implementation_df['Start']
    implementation_df['Duration'] = implementation_df['Duration'].dt.days
    
    # Color mapping for priority
    color_map = {'High': VERATHON_BLUE, 'Medium': '#6FA8DC', 'Low': '#CFE2F3'}
    
    # Create Gantt chart
    gantt_fig = px.timeline(
        implementation_df,
        x_start='Start',
        x_end='Finish',
        y='Task',
        color='Resource',
        title="Implementation Timeline & Priority",
        color_discrete_map=color_map
    )
    
    gantt_fig.update_layout(
        xaxis_title="Timeline",
        yaxis_title="",
        height=400
    )
    
    st.plotly_chart(gantt_fig, use_container_width=True)
    
    # Expected results
    st.subheader("Expected Competitive Position Improvement")
    
    # Create before/after radar chart
    current_vs_future = pd.DataFrame({
        'Dimension': ['Digital Presence', 'Content Marketing', 'Social Media', 'SEO Performance', 'Webinar Program', 'Technology Stack'],
        'Current Position': [5, 6, 4, 5, 7, 6],  # 1-10 scale
        'Future Position': [8, 8, 7, 8, 9, 8]  # 1-10 scale
    })
    
    # Create radar chart comparing current vs future position
    position_fig = go.Figure()
    
    position_fig.add_trace(go.Scatterpolar(
        r=current_vs_future['Current Position'],
        theta=current_vs_future['Dimension'],
        fill='toself',
        name='Current Position',
        line_color='lightgray'
    ))
    
    position_fig.add_trace(go.Scatterpolar(
        r=current_vs_future['Future Position'],
        theta=current_vs_future['Dimension'],
        fill='toself',
        name='Projected Future Position',
        line_color=VERATHON_BLUE
    ))
    
    position_fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 10]
            )
        ),
        title="Projected Competitive Position Improvement",
        showlegend=True,
        height=500
    )
    
    st.plotly_chart(position_fig, use_container_width=True)
    
    # Call to action
    st.markdown("---")
    st.markdown(f"""
    <div style="background-color:{VERATHON_BLUE}; padding:15px; border-radius:5px; text-align:center;">
        <h2 style="color:white;">Ready to transform your competitive position?</h2>
        <p style="color:white;">Contact your Digital Factory 24 representative to schedule a detailed implementation plan.</p>
    </div>
    """, unsafe_allow_html=True)