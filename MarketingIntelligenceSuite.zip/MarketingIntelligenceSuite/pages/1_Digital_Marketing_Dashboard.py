import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
from utils.data_processing import generate_sample_marketing_data
from utils.visualization import create_kpi_indicator

# Page configuration
st.set_page_config(
    page_title="Digital Marketing Dashboard - Verathon",
    page_icon="📈",
    layout="wide"
)

# Header
st.title("Digital Marketing Dashboard")
st.markdown("Track and analyze all your digital marketing KPIs in one place")

# Date filter
col1, col2 = st.columns([1, 3])
with col1:
    date_range = st.selectbox(
        "Select Time Period:",
        ["Last 7 Days", "Last 30 Days", "Last Quarter", "Last Year", "Custom Range"]
    )

# Fetch marketing data (in a real application, this would come from APIs/databases)
marketing_data = generate_sample_marketing_data(period=date_range)

# Campaign Performance Overview
st.header("Campaign Performance Overview")
campaign_metrics_cols = st.columns(4)

with campaign_metrics_cols[0]:
    create_kpi_indicator(
        title="Total Website Traffic", 
        value=marketing_data['website_traffic'].sum(),
        delta=round(marketing_data['website_traffic'].pct_change().iloc[-1] * 100, 1),
        delta_suffix="%"
    )

with campaign_metrics_cols[1]:
    create_kpi_indicator(
        title="Conversion Rate", 
        value=f"{marketing_data['conversion_rate'].mean():.2f}%",
        delta=round((marketing_data['conversion_rate'].iloc[-1] - marketing_data['conversion_rate'].iloc[0]), 2),
        delta_suffix=" pts"
    )

with campaign_metrics_cols[2]:
    create_kpi_indicator(
        title="Avg. Cost Per Lead", 
        value=f"${marketing_data['cost_per_lead'].mean():.2f}",
        delta=-round((marketing_data['cost_per_lead'].iloc[-1] - marketing_data['cost_per_lead'].iloc[0]), 2),
        delta_suffix="$",
        is_inverse=True
    )

with campaign_metrics_cols[3]:
    create_kpi_indicator(
        title="Marketing ROI", 
        value=f"{marketing_data['roi'].mean():.1f}x",
        delta=round((marketing_data['roi'].iloc[-1] - marketing_data['roi'].iloc[0]), 1),
        delta_suffix="x"
    )

# Marketing Channel Performance
st.header("Marketing Channel Performance")
channel_col1, channel_col2 = st.columns([3, 2])

with channel_col1:
    # Traffic by channel chart
    channel_data = pd.DataFrame({
        'Channel': ['Organic Search', 'Paid Search', 'Social Media', 'Email', 'Direct', 'Referral'],
        'Traffic': [35000, 25000, 15000, 12000, 8000, 5000],
        'Conversion Rate': [3.2, 2.8, 2.1, 3.8, 4.2, 1.5]
    })
    
    fig = px.bar(
        channel_data,
        x='Channel',
        y='Traffic',
        color='Conversion Rate',
        color_continuous_scale=px.colors.sequential.Viridis,
        title="Traffic by Channel"
    )
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

with channel_col2:
    # Channel effectiveness
    fig = go.Figure()
    
    for channel in channel_data['Channel']:
        fig.add_trace(go.Indicator(
            mode="number+delta",
            value=np.random.randint(50, 100),
            title={"text": channel},
            delta={'reference': np.random.randint(50, 95), 'relative': True},
            domain={'row': 0, 'column': 0}
        ))
    
    fig.update_layout(
        grid={'rows': 3, 'columns': 2, 'pattern': "independent"},
        title_text="Channel Effectiveness Score",
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

# Content Performance
st.header("Content & Campaign Performance")
content_col1, content_col2 = st.columns(2)

with content_col1:
    # Top performing content
    content_data = pd.DataFrame({
        'Content Title': [
            'Ultimate Guide to Medical Device Marketing', 
            'Webinar: Latest Innovations in Healthcare', 
            'Case Study: Hospital Efficiency Improvement',
            'Product Demo: New Visualization System',
            'Industry Report: Healthcare Trends 2023'
        ],
        'Views': [5200, 3800, 2900, 2700, 2500],
        'Engagement': [0.82, 0.78, 0.65, 0.72, 0.59]
    })
    
    fig = px.scatter(
        content_data,
        x='Views',
        y='Engagement',
        size='Views',
        color='Engagement',
        hover_name='Content Title',
        title="Top Performing Content"
    )
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

with content_col2:
    # Campaign ROI
    campaign_data = pd.DataFrame({
        'Campaign': ['Q1 Email Series', 'Healthcare Expo', 'LinkedIn Ads', 'Partner Webinar', 'Product Launch'],
        'Spend': [15000, 45000, 30000, 12000, 50000],
        'Revenue': [45000, 120000, 72000, 24000, 175000],
    })
    campaign_data['ROI'] = (campaign_data['Revenue'] - campaign_data['Spend']) / campaign_data['Spend']
    
    fig = px.bar(
        campaign_data,
        x='Campaign',
        y='ROI',
        color='Spend',
        title="Campaign ROI Analysis"
    )
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

# Website Performance 
st.header("Website Performance Metrics")
web_col1, web_col2, web_col3 = st.columns(3)

with web_col1:
    # Traffic trend
    fig = px.line(
        marketing_data,
        x='date',
        y='website_traffic',
        title="Website Traffic Trend"
    )
    fig.update_layout(height=300)
    st.plotly_chart(fig, use_container_width=True)

with web_col2:
    # Bounce rate
    fig = px.line(
        marketing_data,
        x='date',
        y='bounce_rate',
        title="Bounce Rate Trend"
    )
    fig.update_layout(height=300)
    st.plotly_chart(fig, use_container_width=True)

with web_col3:
    # Avg time on site
    fig = px.line(
        marketing_data,
        x='date',
        y='avg_session_duration',
        title="Avg. Session Duration"
    )
    fig.update_layout(height=300)
    st.plotly_chart(fig, use_container_width=True)

# Alerts and Recommendations
st.header("Alerts & Recommendations")
alert_col1, alert_col2 = st.columns(2)

with alert_col1:
    st.subheader("Performance Alerts")
    st.warning("⚠️ Bounce rate increased by 12% on product pages")
    st.info("ℹ️ Organic traffic growing 15% above target")
    st.error("🔴 Email campaign open rates below threshold (15%)")
    st.success("✅ LinkedIn ad performance exceeding ROAS targets")

with alert_col2:
    st.subheader("AI-Driven Recommendations")
    st.markdown("""
    - **SEO**: Optimize product pages with more technical specifications
    - **Content**: Create more case studies (high engagement detected)
    - **Paid Media**: Increase budget allocation to LinkedIn campaigns
    - **Email**: Test new subject lines for upcoming healthcare webinar
    """)

# Notes and Actions
st.header("Notes & Action Items")
notes_col1, notes_col2 = st.columns(2)

with notes_col1:
    st.text_area("Add a note to the dashboard", height=100)
    st.button("Save Note")

with notes_col2:
    st.selectbox("Assign action to team member", ["Select team member", "Marketing Manager", "Content Specialist", "Digital Ads Specialist", "SEO Specialist"])
    st.text_input("Action Item")
    st.button("Create Task")
