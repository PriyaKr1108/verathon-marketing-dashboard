import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
from utils.webinar_framework import get_webinar_stage_requirements, generate_webinar_sample_data

# Page configuration
st.set_page_config(
    page_title="Webinar Management - Verathon",
    page_icon="🎥",
    layout="wide"
)

# Header
st.title("Webinar Marketing Management")
st.markdown("Implement and manage the Crawl-Walk-Run webinar framework for Verathon")

# Webinar Framework Overview
st.header("Crawl-Walk-Run Framework")

framework_col1, framework_col2, framework_col3 = st.columns(3)

with framework_col1:
    st.subheader("Crawl Phase")
    st.image("https://images.unsplash.com/photo-1519389950473-47ba0277781c", caption="Basic Framework Implementation")
    st.markdown("""
    **Focus Areas:**
    - Basic webinar setup and execution
    - Simple registration process
    - Essential content delivery
    - Basic post-event follow-up
    - Cvent fundamental features utilization
    """)

with framework_col2:
    st.subheader("Walk Phase")
    st.image("https://images.unsplash.com/photo-1517245386807-bb43f82c33c4", caption="Intermediate Capabilities")
    st.markdown("""
    **Focus Areas:**
    - Advanced registration pathways
    - Interactive webinar elements
    - Segmented follow-up campaigns
    - Customized Cvent integrations
    - Expanded analytics and reporting
    """)

with framework_col3:
    st.subheader("Run Phase")
    st.image("https://images.unsplash.com/photo-1557804506-669a67965ba0", caption="Advanced Implementation")
    st.markdown("""
    **Focus Areas:**
    - AI-powered personalization
    - Advanced audience engagement tools
    - Marketing automation integration
    - Predictive analytics implementation
    - Complete Cvent ecosystem utilization
    """)

# Current Framework Stage Selection
st.header("Verathon's Current Implementation Stage")

current_stage = st.radio(
    "Select your current implementation stage:",
    ["Crawl", "Walk", "Run"],
    horizontal=True
)

st.markdown("---")

# Requirements for the selected stage
st.subheader(f"Requirements for {current_stage} Stage")
requirements = get_webinar_stage_requirements(current_stage)

# Display requirements in columns
req_cols = st.columns(4)
for i, (category, items) in enumerate(requirements.items()):
    with req_cols[i % 4]:
        st.markdown(f"**{category}**")
        for item in items:
            st.markdown(f"- {item}")

# Webinar Performance Metrics
st.header("Webinar Program Performance")

# Generate sample webinar data
webinar_data = generate_webinar_sample_data()

# Metrics overview
metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)

# Extract the last values from program_metrics for display as the current values
with metrics_col1:
    # Get the latest attendance rate
    attendance_rate = webinar_data['program_metrics']['avg_attendance_rates'][-1]
    # Calculate change from previous month
    attendance_change = attendance_rate - webinar_data['program_metrics']['avg_attendance_rates'][-2]
    st.metric(
        label="Average Attendance Rate",
        value=f"{attendance_rate}%",
        delta=f"{attendance_change:.1f}%"
    )

with metrics_col2:
    # Get the latest registrations
    avg_registrations = webinar_data['program_metrics']['avg_registrations'][-1]
    # Calculate change from previous month
    registrations_change = avg_registrations - webinar_data['program_metrics']['avg_registrations'][-2]
    st.metric(
        label="Average Registrations",
        value=f"{avg_registrations}",
        delta=f"{registrations_change:.0f}"
    )

with metrics_col3:
    # Get webinar frequency
    monthly_webinars = webinar_data['program_metrics']['monthly_webinars'][-1]
    # Calculate change from previous month
    webinars_change = monthly_webinars - webinar_data['program_metrics']['monthly_webinars'][-2]
    st.metric(
        label="Monthly Webinars",
        value=f"{monthly_webinars}",
        delta=f"{webinars_change}"
    )

with metrics_col4:
    # Get lead conversion rate
    lead_rate = webinar_data['program_metrics']['lead_conversion_rates'][-1]
    # Calculate change from previous month
    lead_change = lead_rate - webinar_data['program_metrics']['lead_conversion_rates'][-2]
    st.metric(
        label="Lead Conversion Rate",
        value=f"{lead_rate}%",
        delta=f"{lead_change:.1f}%"
    )

# Webinar performance chart
st.subheader("Past Webinar Performance")

# Create a dataframe from the past webinars for visualization
past_webinars_df = pd.DataFrame(webinar_data['past_webinars'])
# Extract the most relevant metrics
past_webinars_for_chart = pd.DataFrame({
    'webinar_title': [webinar['title'][:20] + "..." for webinar in webinar_data['past_webinars']],
    'registrations': [webinar['registrations'] for webinar in webinar_data['past_webinars']],
    'attendance': [webinar['attendance'] for webinar in webinar_data['past_webinars']],
    'leads_generated': [int(webinar['attendance'] * (webinar['mql_conversion_rate']/100)) for webinar in webinar_data['past_webinars']]
})

fig = px.bar(
    past_webinars_for_chart,
    x='webinar_title',
    y=['registrations', 'attendance', 'leads_generated'],
    barmode='group',
    title="Webinar Performance Comparison",
    labels={'value': 'Count', 'variable': 'Metric', 'webinar_title': 'Webinar Title'}
)
st.plotly_chart(fig, use_container_width=True)

# Engagement metrics
st.subheader("Audience Engagement Metrics")
engagement_col1, engagement_col2 = st.columns(2)

with engagement_col1:
    # Create time series of engagement data for a sample webinar
    # Use timestamp and view time percentage from the most recent webinar
    recent_webinar = webinar_data['past_webinars'][0]
    
    # Create a time series dataset for the webinar duration
    engagement_data = []
    webinar_duration_minutes = 60  # Assume 60 minute webinar
    for minute in range(webinar_duration_minutes):
        # Create an engagement curve that rises, plateaus, and falls
        if minute < 15:
            engagement = minute * 6  # Rising engagement
        elif minute < 45:
            engagement = 85 + np.random.randint(-5, 5)  # Plateau with small fluctuations
        else:
            engagement = 85 - ((minute - 45) * 5)  # Falling engagement
        
        engagement = max(min(engagement, 100), 0)  # Ensure within 0-100 range
        
        engagement_data.append({
            'minute': minute,
            'engagement_score': engagement
        })
    
    engagement_df = pd.DataFrame(engagement_data)
    
    fig = px.line(
        engagement_df,
        x='minute',
        y='engagement_score',
        title="Engagement Throughout Webinar Duration",
        labels={'minute': 'Time (minutes)', 'engagement_score': 'Audience Engagement (%)'}
    )
    fig.update_layout(yaxis_range=[0, 100])
    st.plotly_chart(fig, use_container_width=True)

with engagement_col2:
    # Create sample interaction data
    interaction_data = {
        'interaction_type': ['Questions Asked', 'Poll Responses', 'Resource Downloads', 'Chat Messages', 'Emoji Reactions'],
        'count': [42, 95, 68, 123, 57]
    }
    
    fig = px.pie(
        pd.DataFrame(interaction_data),
        values='count',
        names='interaction_type',
        title="Types of Audience Interactions"
    )
    st.plotly_chart(fig, use_container_width=True)

# Upcoming Webinars
st.header("Upcoming Webinar Schedule")
upcoming_df = pd.DataFrame(webinar_data['upcoming_webinars'])
# Format the upcoming webinars dataframe for display
upcoming_display_df = pd.DataFrame({
    'Webinar Title': [webinar['title'] for webinar in webinar_data['upcoming_webinars']],
    'Date': [webinar['date'] for webinar in webinar_data['upcoming_webinars']],
    'Current Registrations': [webinar['current_registrations'] for webinar in webinar_data['upcoming_webinars']],
    'Registration Target': [webinar['registration_target'] for webinar in webinar_data['upcoming_webinars']],
    'Days Until Event': [webinar['days_until_event'] for webinar in webinar_data['upcoming_webinars']],
    'Registration Progress': [f"{webinar['registration_percentage']}%" for webinar in webinar_data['upcoming_webinars']]
})

st.dataframe(upcoming_display_df, use_container_width=True)

# Webinar Planning Tool
st.header("Webinar Planning & Management")
planning_col1, planning_col2 = st.columns(2)

with planning_col1:
    st.subheader("New Webinar Setup")
    st.text_input("Webinar Title")
    st.date_input("Webinar Date")
    st.time_input("Webinar Time")
    st.text_area("Webinar Description", height=100)
    st.selectbox("Target Audience", ["Healthcare Professionals", "Hospital Administrators", "Medical Technicians", "Purchasing Decision Makers"])
    st.multiselect("Content Topics", ["Product Demonstration", "Case Study", "Industry Trends", "Best Practices", "Q&A Session"])
    st.button("Create Webinar in Cvent")

with planning_col2:
    st.subheader("Webinar Promotion Checklist")
    st.markdown("""
    - [ ] Create registration landing page
    - [ ] Design email invitation series
    - [ ] Prepare social media announcements
    - [ ] Brief presenters and finalize content
    - [ ] Set up tracking & analytics
    - [ ] Test webinar platform functionality
    - [ ] Prepare follow-up communications
    - [ ] Create evaluation survey
    """)
    
    st.button("Generate Complete Checklist")

# Cvent Integration Status
st.header("Cvent Integration Status")
cvent_col1, cvent_col2 = st.columns(2)

with cvent_col1:
    st.subheader("Connection Status")
    st.success("✅ Cvent API Connection: Active")
    st.info("ℹ️ Last Sync: Today, 11:23 AM")
    st.warning("⚠️ Partial Data Sync: Custom fields pending")
    
    st.button("Test Connection")
    st.button("Sync Webinar Data")

with cvent_col2:
    st.subheader("Cvent Capabilities Utilized")
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = 65,
        title = {'text': "Cvent Feature Utilization"},
        gauge = {
            'axis': {'range': [None, 100]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 50], 'color': "lightgray"},
                {'range': [50, 75], 'color': "gray"},
                {'range': [75, 100], 'color': "darkgray"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 85
            }
        }
    ))
    st.plotly_chart(fig, use_container_width=True)

    st.button("View Unused Cvent Features")
